## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----setup2, message=FALSE----------------------------------------------------
require(NNS)
require(knitr)
require(rgl)
require(data.table)
require(dtw)

## ----rhs, rows.print=18-------------------------------------------------------
NNS.reg(iris[,1:4], iris[,5], residual.plot = FALSE, ncores = 1)$rhs.partitions

## ----NNSBOOST,fig.align = "center", fig.height = 8,fig.width=6.5--------------
a = NNS.boost(iris[-c(1:10), 1:4], iris[-c(1:10), 5],
              IVs.test = iris[1:10, 1:4],
              epochs = 100, learner.trials = 100, status = FALSE,
              ncores = 1)

a$results

a$feature.weights

mean(round(a$results)==as.numeric(iris[1:10, 5]))

