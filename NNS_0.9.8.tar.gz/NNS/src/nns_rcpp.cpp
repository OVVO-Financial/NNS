// example from: https://github.com/r-pkg-examples/rcpp-headers-src
// [[Rcpp::depends(RcppParallel)]]
#include <Rcpp.h>
#include <RcppParallel.h>

// Load directory header files
#include "partial_moments_rcpp.h"

