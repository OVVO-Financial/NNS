#' NNS ARMA
#'
#' Autoregressive model incorporating nonlinear regressions of component series.
#'
#' @param variable a numeric vector.
#' @param h integer; 1 (default) Number of periods to forecast.
#' @param training.set numeric; \code{NULL} (default) Sets the number of variable observations
#'
#'  \code{(variable[1 : training.set])} to monitor performance of forecast over in-sample range.
#' @param seasonal.factor logical or integer(s); \code{TRUE} (default) Automatically selects the best seasonal lag from the seasonality test, \link{NNS.seas}'s \code{best.period} without its permutation test.  For a significance-filtered lag, run \code{NNS.seas(variable, p.value = TRUE)} first and pass its \code{best.period} (or \code{periods}) here; \code{best.period} is 1 when no period is significant.  To use weighted average of all seasonal lags set to \code{(seasonal.factor = FALSE)}.  Otherwise, directly input known frequency integer lag to use, i.e. \code{(seasonal.factor = 12)} for monthly data.  Multiple frequency integers can also be used, i.e. \code{(seasonal.factor = c(12, 24, 36))}
#' @param modulo integer(s); NULL (default) Adds the multiples of \code{modulo} on either side of each detected period (period 7 with \code{modulo = 5} gives 5 and 10).
#' @param mod.only logical; \code{TRUE} (default) Limits the number of seasonal periods returned to the specified \code{modulo}.
#' @param weights numeric or \code{"equal"}; \code{NULL} (default) sets the weights of the \code{seasonal.factor} vector when specified as integers.  If \code{(weights = NULL)} each \code{seasonal.factor} is weighted on its \link{NNS.seas} result and number of observations it contains, else an \code{"equal"} weight is used.  Numeric weights must have one value per seasonal lag and are treated as relative weights (rescaled to sum to 1).  With \code{(dynamic = TRUE)} the lags are re-selected at every step, so only \code{NULL} or \code{"equal"} weights are accepted.
#' @param best.periods integer; 1 (default) used in conjunction with \code{(seasonal.factor = FALSE)}, uses the \code{best.periods} number of detected seasonal lags instead of \code{ALL} lags when
#' \code{(seasonal.factor = FALSE, best.periods = NULL)}.
#' @param negative.values logical; \code{FALSE} (default) If the variable can be negative, set to
#' \code{(negative.values = TRUE)}.  If there are negative values within the training data \code{variable[1 : training.set]}, \code{negative.values} will automatically be detected.
#' @param method options: ("lin", "nonlin", "both", "means"); \code{"nonlin"} (default)  To select the regression type of the component series, select \code{(method = "both")} where both linear and nonlinear estimates are generated.  To use a nonlinear regression, set to
#' \code{(method = "nonlin")}; to use a linear regression set to \code{(method = "lin")}.  Means for each subset are returned with \code{(method = "means")}.
#' @param dynamic logical; \code{FALSE} (default) To update the seasonal factor with each forecast point, set to \code{(dynamic = TRUE)}.  The default is \code{(dynamic = FALSE)} to retain the original seasonal factor from the inputted variable for all ensuing \code{h}.
#' @param shrink logical; \code{FALSE} (default) Ensembles forecasts with \code{method = "means"}.
#' @param plot logical; \code{TRUE} (default) Returns the plot of all periods exhibiting seasonality and the \code{variable} level reference in upper panel.  Lower panel returns original data and forecast.
#' @param seasonal.plot logical; \code{TRUE} (default) Adds the seasonality plot above the forecast.  Will be set to \code{FALSE} if no seasonality is detected or \code{seasonal.factor} is set to an integer value.
#' @param pred.int numeric [0, 1]; \code{NULL} (default) Plots and returns lower and upper bands around the forecasts.  The forecast path itself is resampled with the maximum entropy bootstrap (\link{NNS.MC} over \code{rho} from -1 to 1), the bounds at each step are \link{LPM.VaR} and \link{UPM.VaR} of the replicates at probability \code{(1 - pred.int) / 2}, widened by the spread of the per-lag linear estimates; a one-point (\code{h = 1}) or constant path has no dispersion to resample, so its band is the path widened by that spread alone (zero width with a single seasonal lag); \link{NNS.ARMA.optim} gives intervals from validation errors.  The band therefore describes the dispersion of the forecast path, not the uncertainty of the outcome at each horizon: it does not widen with the horizon, and it is not calibrated to contain future values with probability \code{pred.int}.  \link{NNS.ARMA.optim} derives its interval from validation errors instead.
#' @return Returns a vector of forecasts of length \code{(h)} if no \code{pred.int} specified.  Else, returns a \code{data.table} with the forecasts as well as the lower and upper forecast-path bands per forecast point (see \code{pred.int}).
#' @note
#' For monthly data series, increased accuracy may be realized from forcing seasonal factors to multiples of 12.  For example, if the best periods reported are: \{37, 47, 71, 73\}  use
#' \code{(seasonal.factor = c(36, 48, 72))}.
#'
#' \code{(seasonal.factor = FALSE)} can be a very computationally expensive exercise due to the number of seasonal periods detected.
#'
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. and Nawrocki, D. (2013) "Nonlinear Nonparametric Statistics: Using Partial Moments" (ISBN: 1490523995, 2nd edition: \url{https://ovvo-financial.github.io/NNS/book/})
#'
#' Viole, F. (2019) "Forecasting Using NNS"  \doi{10.2139/ssrn.3382300}
#'
#' @examples
#'
#' ## Nonlinear NNS.ARMA using AirPassengers monthly data and 12 period lag
#' \dontrun{
#' NNS.ARMA(AirPassengers, h = 45, training.set = 100, seasonal.factor = 12, method = "nonlin")
#'
#' ## Linear NNS.ARMA using AirPassengers monthly data and 12, 24, and 36 period lags
#' NNS.ARMA(AirPassengers, h = 45, training.set = 120, seasonal.factor = c(12, 24, 36), method = "lin")
#'
#' ## Nonlinear NNS.ARMA using AirPassengers monthly data and 2 best periods lag
#' NNS.ARMA(AirPassengers, h = 45, training.set = 120, seasonal.factor = FALSE, best.periods = 2)
#' }
#' @export



# Autoregressive Model
NNS.ARMA <- function(variable,
                     h = 1,
                     training.set = NULL,
                     seasonal.factor = TRUE,
                     weights = NULL,
                     best.periods = 1,
                     modulo = NULL,
                     mod.only = TRUE,
                     negative.values = FALSE,
                     method = "nonlin",
                     dynamic = FALSE,
                     shrink = FALSE,
                     plot = TRUE,
                     seasonal.plot = TRUE,
                     pred.int = NULL){
  
  
  if(is.numeric(seasonal.factor) && dynamic) stop('Hmmm...Seems you have "seasonal.factor" specified and "dynamic = TRUE".  Nothing dynamic about static seasonal factors!  Please set "dynamic = FALSE" or "seasonal.factor = FALSE"')
  
  if(is.numeric(weights) && dynamic) stop('Numeric "weights" cannot be used with "dynamic = TRUE", which re-selects the seasonal lags at every step.  Please set "weights" to NULL or "equal", or "dynamic = FALSE"')
  
  if(any(class(variable)%in%c("tbl","data.table"))) variable <- as.vector(unlist(variable))
  
  if(anyNA(variable)) stop("You have some missing values, please address.")
  
  if(!is.numeric(h) || length(h) != 1L || !is.finite(h) || h < 1 || h != round(h))
    stop("[h] must be a positive integer.")
  
  method <- tolower(method)
  if(method == "means") shrink <- FALSE
  
  oldw <- getOption("warn")
  on.exit(options(warn = oldw), add = TRUE)
  options(warn = -1)
  
  if(!is.null(best.periods) && !is.numeric(seasonal.factor)) seasonal.factor <- FALSE
  # label is only used for plot axis titles; deparse(match.call()) is otherwise
  # pure per-call overhead (NNS.ARMA.optim calls NNS.ARMA hundreds of times with
  # plot = FALSE).  Defer it to the plotting branch.
  label <- if (isTRUE(plot)) deparse(match.call()$variable) else NULL
  variable <- as.numeric(variable)
  OV <- variable
  
  if(!is.null(training.set)){
    variable <- variable[1 : training.set]
    FV <- variable[1 : training.set]
  } else {
    training.set <- length(variable)
    FV <- variable
  }
  
  if(min(variable) < 0) negative.values <- TRUE
  
  Estimates <- numeric(length = h)
  
  
  if(is.numeric(seasonal.factor)){
    seasonal.plot = FALSE
    M <- matrix(seasonal.factor, ncol=1)
    colnames(M) <- "Period"
    lag <- seasonal.factor
    output <- numeric(length(seasonal.factor))
    for(i in 1 : length(seasonal.factor)){
      rev.var <- variable[seq(length(variable), 1, -seasonal.factor[i])]
      output[i] <- abs(sd(rev.var) / mean(rev.var))
    }
    
    if(is.null(weights)){
      Relative.seasonal <- output / abs(sd(variable)/mean(variable))
      # Floor the CV ratio: a perfectly stable lag-subsample (CV 0) in an otherwise-
      # varying series gives Relative.seasonal 0 -> 1/0 = Inf -> Inf/Inf = NaN in the
      # normalisation below, silently poisoning the forecast.  pmax keeps a fully
      # constant series (Relative.seasonal NaN) propagating NaN, matching prior behaviour.
      Seasonal.weighting <- 1 / pmax(Relative.seasonal, .Machine$double.eps)
      Observation.weighting <- 1 / sqrt(seasonal.factor)
      Weights <- (Seasonal.weighting * Observation.weighting) / sum(Observation.weighting * Seasonal.weighting)
      # A constant series has CV 0/0 = NaN for every lag: weight the lags equally.
      if(any(!is.finite(Weights))) Weights <- rep(1/length(lag), length(lag))
      seasonal.plot <- FALSE
    } else {
      Weights <- weights
    }
    
  } else {
    M <- NNS.seas(variable, plot=FALSE, modulo = modulo, mod.only = mod.only)
    if(!is.list(M)){
      M <- t(1)
    } else {
      if(is.null(best.periods)){
        M <- M$all.periods
      } else {
        M <- M$all.periods[1 : min(best.periods, length(M$all.periods$Period)), ]
      }
    }
    
    ASW <- .arma_lag_weights(seasonal.factor, M)
    lag <- ASW$lag
    
    if(is.null(weights)) Weights <- ASW$Weights else Weights <- weights
    
    if(is.character(weights)) Weights <- rep(1/length(lag), length(lag))
    
  }
  
  # User-supplied weights: "equal", or one relative weight per lag.
  if(!is.null(weights)){
    if(is.character(weights)){
      Weights <- rep(1/length(lag), length(lag))
    } else {
      if(length(weights) != length(lag)) stop("weights must have one value per seasonal lag (length(weights) == length(seasonal.factor)).")
      if(!all(is.finite(weights)) || sum(weights) == 0) stop("weights must be finite and must not sum to 0.")
      Weights <- weights / sum(weights)
    }
  }
  
  # Vectorized linear
  Lin.Reg.Estimates <- list()
  Regression.Estimates_means <- list()
  
  # Shrunk estimates leave the fitted line, so steps past the lag need the recursive refit below.
  # With several lags, the loop below feeds each step's combined forecast back
  # into the series, but a lag's component series only reaches it at steps
  # beyond that lag. When every lag is at least h (and within the series), each
  # lag's forecasts are its own fitted line, as with one lag, and combining them
  # step by step gives the loop's result.
  direct.lags <- length(lag) > 1 && all(lag >= h) && all(lag <= length(variable))
  if (method == "lin" && !shrink && is.numeric(seasonal.factor) &&
      (length(seasonal.factor) == 1 || direct.lags)) {
    unweighted <- vector("list", length(lag))
    for(lag.idx in seq_along(lag)) {
      GV.lin <- generate.lin.vectors(variable, lag[lag.idx], h)
      
      # Generate linear regression estimates for each lag
      Lin.Regression.Estimates <- lapply(1:min(h, lag[lag.idx]), function(i) {
        lin.reg <- fast_lm(GV.lin$Component.index[[i]], GV.lin$Component.series[[i]])
        coefs <- lin.reg$coef
        
        return(as.numeric(coefs[1] + coefs[2] * unlist(GV.lin$forecast.values[[i]])))
      })
      
      unweighted[[lag.idx]] <- unlist(Lin.Regression.Estimates)[order(unlist(GV.lin$forecast.index))]
      Lin.Reg.Estimates[[lag.idx]] <- unweighted[[lag.idx]] * Weights[lag.idx]
    }
    
    # Weighted sum over the lags at each step. rowSums() adds the lags in the
    # loop's order and precision (sum() of the weighted per-lag estimates).
    if (length(lag) == 1) {
      Lin.estimates <- Lin.Reg.Estimates[[1]]
    } else {
      Lin.estimates <- rowSums(do.call(cbind, Lin.Reg.Estimates))
      # pred.int reads the per-lag estimates of the loop's last step.
      Lin.Regression.Estimates <- vapply(unweighted, function(e) e[h], numeric(1))
    }
    
    if(!negative.values) Lin.estimates <- pmax(0, Lin.estimates)
    
    Estimates <- Lin.estimates
    variable <- c(variable, Estimates)
    FV <- variable
  } else {
    
    # Regression for each estimate in h
    for (j in 1:h) {
      # Regenerate seasonal.factor if dynamic
      if (dynamic) {
        # Same period selection as the static path, on the extended series.
        seas.matrix <- NNS.seas(variable, plot = FALSE, modulo = modulo, mod.only = mod.only)
        if (!is.list(seas.matrix)) {
          M <- t(1)
        } else {
          M <- seas.matrix$all.periods
          if (!is.null(best.periods)) {
            M <- M[1:min(best.periods, length(M$Period)), ]
          }
        }
        
        ASW <- .arma_lag_weights(seasonal.factor, M)
        lag <- ASW$lag
        Weights <- ASW$Weights
        if(is.character(weights)) Weights <- rep(1/length(lag), length(lag))
      }
      
      # Re-Generate vectors for 1:lag if dynamic
      GV <- generate.vectors(variable, lag)
      Component.index <- GV$Component.index
      Component.series <- GV$Component.series
      
      # Regression on Component Series
      ## Regression on Component Series
      if (method %in% c("nonlin", "both")) {
        Regression.Estimates <- sapply(seq_along(lag), function(i) {
          x <- Component.index[[i]]
          y <- Component.series[[i]]
          
          last.y <- y[length(y)]
          
          reg.points <- NNS.reg(x, y, type = "REG", return.values = FALSE, plot = FALSE, multivariate.call = TRUE)
          
          rpx <- reg.points$x; rpy <- reg.points$y
          ok <- !(is.na(rpx) | is.na(rpy))
          rpx <- rpx[ok]; rpy <- rpy[ok]
          xs <- rpx[length(rpx)] - rpx
          ys <- rpy[length(rpy)] - rpy
          
          xs <- xs[-length(xs)]
          ys <- ys[-length(ys)]
          
          # Squared-index weighted means of the run and rise, mean(rep(xs, w)) with
          # w = (1:k)^2, without building the sum(w) ~ k^3/3 long vector: that cost
          # grew cubically with the number of regression points on long series.
          w <- (1:length(xs))^2
          run <- sum(w * xs) / sum(w)
          rise <- sum(w * ys) / sum(w)
          
          last.y + (rise / run)
        })
        
        if(shrink) Regression.Estimates <- (Regression.Estimates + sapply(Component.series, mean)) / 2
        if(!negative.values) Regression.Estimates <- pmax(0, Regression.Estimates)
        Nonlin.estimates <- sum(Regression.Estimates * Weights)
      }
      
      if ((method %in% c("lin", "both", "means")) || is.numeric(pred.int)) {
        Lin.Regression.Estimates <- sapply(seq_along(lag), function(i) {
          ci <- Component.index[[i]]
          last.x <- ci[length(ci)]
          lin.reg <- fast_lm(ci, Component.series[[i]])
          coefs <- lin.reg$coef
          return(as.numeric(coefs[1] + coefs[2] * (last.x + 1)))
        })
        
        Lin.Regression.Estimates <- unlist(Lin.Regression.Estimates)
        # A single lag longer than the history has nothing to fit: NaN, as the direct path gives.
        if (length(lag) == 1 && length(Lin.Regression.Estimates) == 0) Lin.Regression.Estimates <- NaN
        
        if ((method == "means") || shrink) {
          Regression.Estimates_means <- sapply(Component.series, mean)
          if (shrink) Lin.Regression.Estimates <- (Lin.Regression.Estimates + Regression.Estimates_means) / 2 else Lin.Regression.Estimates <- Regression.Estimates_means
        }
        
        Lin.estimates <- sum(Lin.Regression.Estimates * Weights)
        if(!negative.values)  Lin.estimates <- pmax(0, Lin.estimates)
      }
      
      # Lin.estimates / Nonlin.estimates are already weighted sums over lags.
      if (method == "lin") Estimates[j] <- Lin.estimates
      if (method == "means") Estimates[j] <- Lin.estimates
      if (method == 'both') Estimates[j] <- mean(c(Lin.estimates, Nonlin.estimates))
      if (method == "nonlin")  Estimates[j] <- Nonlin.estimates
      
      variable <- c(variable, Estimates[j])
      FV <- variable
    } # j loop
  }
  
  if(!is.null(pred.int)){
    if (method != "means"){
      Lin.Regression.Estimates <- unlist(Lin.Regression.Estimates)
      lin.resid <- mean(abs(Lin.Regression.Estimates - mean(Lin.Regression.Estimates)))
    } else lin.resid <- 0
    # A one-point (h = 1) or constant path has no dispersion to resample, and
    # the bootstrap can't target rho on it (#98): the band is the path widened
    # by the per-lag spread alone.
    if (length(Estimates) < 2L || length(unique(Estimates[!is.na(Estimates)])) < 2L) {
      PIs <- matrix(Estimates, ncol = 1L)
    } else {
      PIs <- do.call(cbind, NNS.MC(Estimates, lower_rho = -1, upper_rho = 1, by = .2)$replicates)
    }
    lin.resid <- mean(unlist(lin.resid))
    lin.resid[is.na(lin.resid)] <- 0
    
    upper_lower <- apply(PIs, 1, function(z) list(UPM.VaR((1-pred.int)/2, 0, z), LPM.VaR((1-pred.int)/2, 0, z))) 
    upper_PIs <- as.numeric(lapply(upper_lower, `[[`, 1)) + lin.resid
    lower_PIs <- as.numeric(lapply(upper_lower, `[[`, 2)) - lin.resid
  } else lin.resid <- 0
  
  #### PLOTTING
  if(plot){
    original.par = par(no.readonly = TRUE)
    if(seasonal.plot){
      par(mfrow = c(2, 1))
      if(ncol(M) > 1){
        plot(unlist(M[, 1]), unlist(M[, 2]),
             xlab = "Period", ylab = "Coefficient of Variation", main = "Seasonality Test", ylim = c(0, 1.5 * unlist(M[, 3])[1]))
        points(unlist(M[ , 1]), unlist(M[ , 2]), pch = 19, col = 'red')
        abline(h = unlist(M[, 3])[1], col = "red", lty = 5)
        text((min(unlist(M[ , 1])) + max(unlist(M[ , 1]))) / 2, unlist(M[, 3])[1], pos = 3, "Variable Coefficient of Variation", col = 'red')
      } else {
        plot(1,1, pch = 19, col = 'blue', xlab = "Period", ylab = "Coefficient of Variation", main = "Seasonality Test",
             ylim = c(0, 2 * abs(sd(FV) / mean(FV))))
        text(1, abs(sd(FV) / mean(FV)), pos = 3, "NO SEASONALITY DETECTED", col = 'red')
      }
    }
    
    
    if(is.null(label)) label <- "Variable"
    
    
    if(!is.null(pred.int)){
      plot(OV, type = 'l', lwd = 2, main = "NNS.ARMA Forecast", col = 'steelblue',
           xlim = c(1, max((training.set + h), length(OV))),
           ylab = label, ylim = c(min(Estimates, OV,  unlist(PIs) ), max(OV, Estimates, unlist(PIs) )) )
      
      
      polygon(c((training.set+1) : (training.set+h), rev((training.set+1) : (training.set+h))),
              c(lower_PIs, rev(upper_PIs)),
              col = rgb(1, 192/255, 203/255, alpha = 0.5),
              border = NA)
      
      
      lines(OV, type = 'l', lwd = 2, col = 'steelblue')
      
      lines((training.set + 1) : (training.set + h), Estimates, type = 'l', lwd = 2, lty = 1, col = 'red')
      segments(training.set, FV[training.set], training.set + 1, Estimates[1],lwd = 2,lty = 1,col = 'red')
      legend('topleft', bty = 'n', legend = c("Original", paste0("Forecast ", h, " period(s)")), lty = c(1, 1), col = c('steelblue', 'red'), lwd = 2)
    } else {
      plot(OV, type = 'l', lwd = 2, main = "NNS.ARMA Forecast", col = 'steelblue',
           xlim = c(1, max((training.set + h), length(OV))),
           ylab = label, ylim = c(min(Estimates, OV), max(OV, Estimates)))
      
      if(training.set[1] < length(OV)){
        lines((training.set + 1) : (training.set + h), Estimates, type = 'l',lwd = 2, lty = 3, col = 'red')
        segments(training.set, FV[training.set], training.set + 1, Estimates[1], lwd = 2, lty = 3, col = 'red')
        legend('topleft', bty = 'n', legend = c("Original", paste0("Forecast ", h, " period(s)")), lty = c(1, 2), col = c('steelblue', 'red'), lwd = 2)
      } else {
        lines((training.set + 1) : (training.set + h), Estimates, type = 'l', lwd = 2, lty = 1, col = 'red')
        segments(training.set, FV[training.set], training.set + 1, Estimates[1], lwd = 2, lty = 1, col = 'red')
        legend('topleft', bty = 'n', legend = c("Original", paste0("Forecast ", h, " period(s)")),lty = c(1, 1), col = c('steelblue', 'red'), lwd = 2)
      }
      
      
    }
    points(training.set, OV[training.set], col = "green", pch = 18)
    points(training.set + h, tail(FV, 1), col = "green", pch = 18)
    
    par(original.par)
  }
  
  if(!is.null(pred.int)){
    results <- cbind.data.frame(Estimates,  pmin(Estimates, lower_PIs),  pmax(Estimates, upper_PIs))
    colnames(results) = c("Estimates",
                          paste0("Lower ", round(pred.int*100,2), "% pred.int"),
                          paste0("Upper ", round(pred.int*100,2), "% pred.int"))
    return(.NNS.df(results))
  } else {
    return(Estimates)
  }
}


# Lags and weights from an NNS.seas period table. seasonal.factor = TRUE takes
# the first row; ARMA.seas.weighting(TRUE, .) expects the list, not the table.
.arma_lag_weights <- function(sf, M){
  if (isTRUE(sf) && is.data.frame(M) && "Period" %in% names(M)) {
    return(list(lag = M$Period[1], Weights = 1))
  }
  ASW <- ARMA.seas.weighting(sf, M)
  # The weights are (VarCV - CV) / sqrt(lag), normalised: all 0 when every
  # CV == VarCV, which forced a forecast of 0.
  w <- ASW$Weights
  if (length(ASW$lag) > 0 && (length(w) == 0 || all(w == 0) || any(!is.finite(w)))) {
    ASW$Weights <- rep(1 / length(ASW$lag), length(ASW$lag))
  }
  ASW
}
