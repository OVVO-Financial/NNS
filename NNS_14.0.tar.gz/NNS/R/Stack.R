#' NNS Stack
#'
#' Prediction model using the predictions of the NNS base models \link{NNS.reg} as features (i.e. meta-features) for the stacked model.
#'
#' @param IVs.train a vector, matrix or data frame of variables of numeric or factor data types.
#' @param DV.train a numeric or factor vector with compatible dimensions to \code{(IVs.train)}.
#' @param IVs.test a vector, matrix or data frame of variables of numeric or factor data types with compatible dimensions to \code{(IVs.train)}.  If NULL, will use \code{(IVs.train)} as default.  Columns are matched to \code{(IVs.train)} by name when the two share the same predictor names, and positionally when they share no names at all (as in \code{cbind(test.x_1, test.x_2)} against \code{cbind(x_1, x_2)}).  A CSV UTF-8 byte-order mark in the first header (for example, \code{Male} becoming \code{X...Male}) is repaired before matching names. Other partial overlaps, including misspelled predictors, are ambiguous and return an error.
#' @param type \code{NULL} (default) automatically classifies factor, character, logical and two-valued numeric responses. Set \code{type = "CLASS"} for nominal classification of any numeric labels, or \code{type = "REG"} to fit a numeric response as regression regardless of its number of distinct values. Forecasting calls use \code{type = "REG"}.
#' @param obj.fn expression; \code{expression(sum((predicted - actual)^2))} (default) Sum of squared errors is the default objective function.  Any \code{expression()} using the specific terms \code{predicted} and \code{actual} can be used.
#' @param objective options: ("min", "max") \code{"min"} (default) Select whether to minimize or maximize the objective function \code{obj.fn}.
#' @param optimize.threshold logical; \code{TRUE} (default) Optimizes the threshold for the second first-observed class in binary classification; multiclass decisions use the largest class probability.  If \code{FALSE}, returns 0.5.
#' @param dist options:(NULL, "NNS", "L1", "L2", "FACTOR") the method of distance calculation. \code{dist = NULL} is the default and selects the native blended NNS distance; \code{dist = "NNS"} is an explicit alias for the default. \code{dist = "L2"} selects Euclidean distance; \code{dist = "L1"} selects Manhattan distance; \code{dist = "FACTOR"} uses a frequency.
#' @param CV.size numeric [0, 1]; \code{NULL} (default) Sets the holdout size for repeated holdout cross-validation (one random holdout per fold).  With \code{CV.size = NULL} and \code{folds > 1}, (stratified, for classification) k-fold cross-validation is used; with \code{CV.size = NULL} and \code{folds = 1}, a single holdout of random size between 0.2 and 0.33 is used.
#' @param balance logical; \code{FALSE} (default) Uses both up and down sampling to balance the classes.  \code{type="CLASS"} required.
#' @param ts.test integer; NULL (default) Sets the length of the test set for time-series data; typically \code{2*h} parameter value from \link{NNS.ARMA} or double known periods to forecast.
#' @param folds integer; \code{folds = 5} (default) Select the number of cross-validation folds.
#' @param order options: (integer, "max", NULL); \code{NULL} (default) Sets the order for \link{NNS.reg}, where \code{(order = "max")} is the k-nearest neighbors equivalent, which is suggested for mixed continuous and discrete (unordered, ordered) data.
#' @param method numeric options: (1, 2); Select the NNS method to include in stack.  \code{(method = 1)} selects \link{NNS.reg}; \code{(method = 2)} selects \link{NNS.reg} dimension reduction regression.  Defaults to \code{method = c(1, 2)}, which will reduce the dimension first, then find the optimal \code{n.best}.
#' @param stack logical; \code{TRUE} (default) Uses dimension reduction to select actual predictor coordinates for the multivariate neighbour search; the dimension-reduction component separately uses its synthetic index. If FALSE, both components use their own full predictor designs.
#' @param dim.red.method options: ("cor", "NNS.dep", "NNS.caus", "equal", "all") method for determining synthetic X* coefficients.  \code{(dim.red.method = "cor")} (default) uses Spearman rank correlation for weights.  \code{(dim.red.method = "NNS.dep")} uses \link{NNS.dep} for nonlinear dependence weights, while \code{(dim.red.method = "NNS.caus")} uses \link{NNS.caus} for directional association weights.  \code{(dim.red.method = "all")} averages all methods for further feature engineering.
#' @param pred.int numeric [0,1]; \code{NULL} (default) Returns the associated prediction intervals with each \code{method}.
#' @param status logical; \code{TRUE} (default) Prints status update message in console.
#' @param ncores integer; value specifying the number of cores to be used in the parallelized subroutine \link{NNS.reg}. If NULL (default), the number of cores to be used is equal to the number of cores of the machine - 1.
#' @param .validation Internal forecast-validation contract, normally NULL. A list with \code{IVs.train}, \code{DV.train}, \code{IVs.test}, and \code{DV.test} supplies the single chronological validation fold when \code{ts.test} is set, \code{folds = 1}, and \code{CV.size = NULL}. It requires exactly \code{N-ts.test} training rows and one through \code{ts.test} held-out rows; this allows scoring only observed future targets. Training prefixes and generated validation predictors must be constructed without later data. Used only for regression tuning; numeric two-level responses remain regression when this contract is supplied with type = NULL. The final model still fits all original training observations.
#' @param seed Optional integer random seed used for reproducible resampling, fold construction, and stochastic fitting steps. If `NULL`, the current random-number-generator state is used.
#'
#' @return Returns a vector of fitted values for the dependent variable test set for all models.
#' \itemize{
#' \item{\code{"NNS.reg.n.best"}} returns the optimum \code{"n.best"} parameter for the \link{NNS.reg} multivariate regression; when all regression points (for classification, all cells) are selected, their number in the final fit. \code{NA} for a single predictor in regression, whose univariate \link{NNS.reg} fit has no \code{n.best} to tune (use \code{cbind(x, x)} to search one), and when \code{method} does not include 1.  \code{"SSE.reg"} returns the SSE for the \link{NNS.reg} multivariate regression.
#' \item{\code{"OBJfn.reg"}} returns the best \code{obj.fn} value of the \link{NNS.reg} regression's tuning on the out-of-fold predictions; it is selection-optimized, not an estimate of out-of-sample performance.
#' \item{\code{"NNS.dim.red.threshold"}} returns the coefficient cutoff at which \link{NNS.reg} on \code{(IVs.train, DV.train)} with the same \code{dim.red.method} keeps the tuned number of predictors: the smallest kept coefficient magnitude, or 0 when every predictor is kept. Ties at the cutoff keep every tied predictor. For classification it is one number when every class index shares the cutoff, as two-class indices always do, and otherwise one cutoff per class, which \link{NNS.reg} accepts as \code{threshold}. \code{NA} when \code{method} does not include 2.
#' \item{\code{"NNS.dim.red.variables"}} returns the names of the predictors carried by the final dimension reduction regression, ranked by absolute coefficient.  With \code{(stack = TRUE)} these are also the only predictors used by the \link{NNS.reg} multivariate regression, so they are exactly the variables behind \code{"stack"}.  \code{NULL} when \code{method} does not include 2.
#' \item{\code{"NNS.dim.red.coefficients"}} returns the named final dimension reduction coefficients for every encoded predictor column (zero for predictors not selected).  \code{NULL} when \code{method} does not include 2.
#' \item{\code{"OBJfn.dim.red"}} returns the best \code{obj.fn} value of the \link{NNS.reg} dimension reduction regression's tuning on the out-of-fold predictions; it is selection-optimized, not an estimate of out-of-sample performance.
#' \item{\code{"probability.threshold"}} returns the optimum probability threshold for classification, else 0.5 when set to \code{FALSE}.
#' \item{\code{"reg"}} returns \link{NNS.reg} output.
#' \item{\code{"reg.pred.int"}} returns the prediction intervals for the regression output.
#' \item{\code{"dim.red"}} returns \link{NNS.reg} dimension reduction regression output.
#' \item{\code{"dim.red.pred.int"}} returns the prediction intervals for the dimension reduction regression output.
#' \item{\code{"stack"}} returns the output of the stacked model.
#' \item{\code{"pred.int"}} returns the prediction intervals for the stacked model.
#' \item{\code{"weights"}} returns the weights of \code{"reg"} and \code{"dim.red"} in \code{"stack"}. For classification they are proportional to the squared \code{"OBJfn.reg"} and \code{"OBJfn.dim.red"} (inverse squares when \code{objective = "min"}); for regression the weight is selected by \code{obj.fn} on the out-of-fold predictions of the blend.
#' }
#'
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. (2016) "Classification Using NNS Clustering Analysis"  \doi{10.2139/ssrn.2864711}
#'
#' @details
#' Classification tunes and combines class-probability vectors from the NNS predictor cells, preserving nominal label identity. \code{probabilities}, \code{reg.probabilities}, and \code{dim.red.probabilities} return the final probability matrices. Class balancing resamples the training rows of each fold. The neighbour count and the dimension count are chosen by optimizing \code{obj.fn} on the pooled out-of-fold predictions; the default classification objective is accuracy. As in NNS 13.0, the two models' probability vectors are then blended with weights proportional to their squared objective scores (inverse squares when \code{objective = "min"}), so models with nearly equal scores are blended nearly equally, and the binary probability threshold is tuned on the out-of-fold predictions of that blend. \code{OBJfn.reg} and \code{OBJfn.dim.red} are the best scores of that search on the same predictions, so they are selection-optimized and overstate held-out performance; assess the final model on an independent test set. Custom objectives receive original numeric or logical response values, and factor/character codes as identified by \code{class.levels}. Relabelling is invariant for label-invariant objectives such as accuracy; a custom loss assigning different costs to classes can deliberately change the result.
#' 
#' Named numeric dimension-reduction coefficients are matched to encoded predictor names in both regression and classification. Factor columns use \code{predictor__level} names; unnamed vectors follow encoded column order. Classification dimension reduction uses one signed index per class indicator. Its reported coefficients are a list of class-specific equations. The tuned dimension count is returned as \code{NNS.dim.red.count}, and \code{NNS.dim.red.threshold} gives the coefficient cutoff that keeps that count in every class index: one number when the class indices share it, as two-class indices always do, and otherwise one cutoff per class. The field \code{NNS.dim.red.variables} is the union of their active encoded columns. These equations describe the synthetic indices, not a complete saved prediction model: reconstruction also requires training-fitted scaling, the predictor cells, their class frequencies, and the selected smoothing controls. With \code{stack = TRUE}, the multivariate classification component retains the selected number of actual encoded coordinates ranked by maximum class-indicator dependence. \code{Prediction.set} contains classes attaining the requested estimated probability mass. Binary interval fields contain the range of this set for compatibility; multiclass interval fields are NULL. The sets do not assert calibrated coverage.
#' 
#' For regression, all dimension-reduction coefficients, normalizations, and candidate predictions used in validation are fitted to the corresponding training fold. The final coefficients and regressions are refitted to the full supplied training data. Method 1 retains the selected predictor coordinates, while method 2 evaluates their signed synthetic index; the components can therefore represent different regression geometry.
#'
#' @note
#' \itemize{
#' \item Incorporate any objective function from external packages (such as \code{Metrics::mape}) via \code{NNS.stack(..., obj.fn = expression(Metrics::mape(actual, predicted)), objective = "min")}
#' 
#' \item Like a logistic regression, the \code{(type = "CLASS")} setting is not necessary for target variable of two classes e.g. [0, 1].  Numeric class values are returned on their original scale; factor and character responses use codes with the returned \code{class.levels} mapping.
#'
#' \item Missing data should be handled prior as well using \link{na.omit} or \link{complete.cases} on the full dataset.
#' }
#'
#' @examples
#'  ## Using 'iris' dataset with a stratified test set of ten rows per species
#'  ## (rows 141:150 alone are all virginica).
#'  \dontrun{
#'  test.set <- c(41:50, 91:100, 141:150)
#'  NNS.stack(iris[-test.set, 1:4], iris[-test.set, 5], IVs.test = iris[test.set, 1:4],
#'  type = "CLASS", balance = TRUE)
#'
#'  ## Using 'iris' dataset to determine [n.best] and [threshold] with no test set.
#'  NNS.stack(iris[ , 1:4], iris[ , 5], type = "CLASS")
#'  }
#' @export


NNS.stack <- function(IVs.train,
                      DV.train,
                      IVs.test = NULL,
                      type = NULL,
                      obj.fn = expression(sum((predicted - actual)^2)),
                      objective = "min",
                      optimize.threshold = TRUE,
                      dist = NULL,
                      CV.size = NULL,
                      balance = FALSE,
                      ts.test = NULL,
                      folds = 5,
                      order = NULL,
                      method = c(1, 2),
                      stack = TRUE,
                      dim.red.method = "cor",
                      pred.int = NULL,
                      status = TRUE,
                      ncores = NULL,
                      seed = 123L,
                      .validation = NULL) {
  
  # -------------------------------------------------------------------------
  # Validation, coercion, and state helpers
  # -------------------------------------------------------------------------
  
  .scalar_logical <- function(x, name) {
    if (!is.logical(x) || length(x) != 1L || is.na(x)) {
      stop(sprintf("[%s] must be TRUE or FALSE.", name), call. = FALSE)
    }
    x
  }
  
  .scalar_integer <- function(x, name, minimum = 0L, allow_null = FALSE) {
    if (allow_null && is.null(x)) return(NULL)
    if (!is.numeric(x) || length(x) != 1L || !is.finite(x) ||
        x < minimum || x != floor(x)) {
      stop(sprintf("[%s] must be an integer >= %d.", name, minimum),
           call. = FALSE)
    }
    as.integer(x)
  }
  
  .as_train_frame <- function(x) {
    if (any(class(x) %in% c("tbl", "data.table"))) x <- as.data.frame(x)
    if (is.null(dim(x))) x <- data.frame(X1 = x, check.names = FALSE)
    x <- as.data.frame(x, check.names = FALSE, stringsAsFactors = FALSE)
    if (ncol(x) < 1L) {
      stop("[IVs.train] must contain at least one predictor.", call. = FALSE)
    }
    if (is.null(names(x)) || any(names(x) == "")) {
      names(x) <- paste0("X", seq_len(ncol(x)))
    }
    # De-duplicate repeated predictor names with make.unique() exactly as
    # NNS.reg's .nns_reg_as_frame() does, so the cbind(x, x) dimension trick
    # works in NNS.stack instead of erroring. c("x", "x") becomes
    # c("x", "x.1").
    names(x) <- make.unique(names(x), sep = ".")
    x
  }
  
  .as_test_frame <- function(x, train_names) {
    p <- length(train_names)
    had_names <- !is.null(dim(x)) && !is.null(colnames(x)) &&
      length(colnames(x)) == NCOL(x) && all(colnames(x) != "")
    
    if (any(class(x) %in% c("tbl", "data.table"))) {
      had_names <- !is.null(names(x)) && all(names(x) != "")
      x <- as.data.frame(x)
    }
    
    if (is.null(dim(x))) {
      if (p == 1L) {
        x <- data.frame(x, check.names = FALSE)
        names(x) <- train_names
      } else if (length(x) == p) {
        supplied <- names(x)
        if (!is.null(supplied) && all(nzchar(supplied))) {
          # Normalize duplicate names exactly as the training frame does, then
          # align by name only when the two name sets describe the same
          # predictors.
          supplied <- make.unique(supplied, sep = ".")
          ordering <- .nns_match_predictor_names(supplied, train_names, "IVs.test")
          if (!is.null(ordering)) x <- x[ordering]
        }
        x <- as.data.frame(as.list(x), check.names = FALSE,
                           stringsAsFactors = FALSE)
        names(x) <- train_names
      } else {
        stop(paste0(
          "A vector [IVs.test] must contain one complete test row, unless ",
          "[IVs.train] has one predictor."
        ), call. = FALSE)
      }
    } else {
      x <- as.data.frame(x, check.names = FALSE, stringsAsFactors = FALSE)
    }
    
    if (ncol(x) != p) {
      stop("[IVs.test] must have the same number of predictors as [IVs.train].",
           call. = FALSE)
    }
    
    if (had_names) {
      # Normalize duplicate names with make.unique() identically to the
      # training frame (and to NNS.reg), so cbind(x, x) test input aligns
      # with the c("x", "x.1") training columns rather than erroring.
      supplied <- make.unique(names(x), sep = ".")
      ordering <- .nns_match_predictor_names(supplied, train_names, "IVs.test")
      if (!is.null(ordering)) x <- x[, ordering, drop = FALSE]
    }
    names(x) <- train_names

    x
  }
  
  .align_predictors <- function(train, test) {
    for (j in seq_along(train)) {
      nm <- names(train)[j]
      tr <- train[[j]]
      te <- test[[j]]
      
      if (inherits(tr, "Date")) {
        if (!inherits(te, "Date")) {
          stop(sprintf("Test predictor [%s] must also be a Date.", nm),
               call. = FALSE)
        }
        train[[j]] <- as.numeric(tr)
        test[[j]] <- as.numeric(te)
      } else if (inherits(tr, c("POSIXct", "POSIXlt"))) {
        if (!inherits(te, c("POSIXct", "POSIXlt"))) {
          stop(sprintf("Test predictor [%s] must also be a date-time value.", nm),
               call. = FALSE)
        }
        train[[j]] <- as.numeric(tr)
        test[[j]] <- as.numeric(te)
      } else if (is.factor(tr) || is.character(tr)) {
        tr_chr <- as.character(tr)
        te_chr <- as.character(te)
        # Sorted levels, as factor() and NNS.boost use, so row order does not
        # matter. A factor's declared levels remain valid test values even when
        # the training rows do not contain every level.
        lev <- if (is.ordered(tr)) levels(tr) else
          if (is.factor(tr)) sort(levels(tr)) else sort(unique(tr_chr))
        unseen <- setdiff(unique(te_chr), lev)
        if (length(unseen)) {
          stop(sprintf(
            "Test predictor [%s] contains unseen level(s): %s.",
            nm, paste(unseen, collapse = ", ")
          ), call. = FALSE)
        }
        train[[j]] <- factor(tr_chr, levels = lev, ordered = is.ordered(tr))
        test[[j]] <- factor(te_chr, levels = lev, ordered = is.ordered(tr))
      } else if (is.logical(tr)) {
        if (!is.logical(te)) {
          stop(sprintf("Test predictor [%s] must also be logical.", nm),
               call. = FALSE)
        }
      } else if (is.numeric(tr) || is.integer(tr)) {
        if (!(is.numeric(te) || is.integer(te))) {
          stop(sprintf("Test predictor [%s] must be numeric.", nm),
               call. = FALSE)
        }
        train[[j]] <- as.numeric(tr)
        test[[j]] <- as.numeric(te)
      } else {
        stop(sprintf("Unsupported predictor type for [%s].", nm),
             call. = FALSE)
      }
    }
    list(train = train, test = test)
  }
  
  .check_predictors <- function(x, name) {
    if (anyNA(x)) stop(sprintf("[%s] contains missing values.", name), call. = FALSE)
    for (j in seq_along(x)) {
      if (is.numeric(x[[j]]) && any(!is.finite(x[[j]]))) {
        stop(sprintf("[%s] predictor [%s] contains non-finite values.",
                     name, names(x)[j]), call. = FALSE)
      }
    }
  }
  
  .restore_rng <- local({
    existed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    old <- if (existed) get(".Random.seed", envir = .GlobalEnv,
                            inherits = FALSE) else NULL
    function() {
      if (existed) {
        assign(".Random.seed", old, envir = .GlobalEnv)
      } else if (exists(".Random.seed", envir = .GlobalEnv,
                        inherits = FALSE)) {
        rm(".Random.seed", envir = .GlobalEnv)
      }
    }
  })
  on.exit(.restore_rng(), add = TRUE)
  
  optimize.threshold <- .scalar_logical(optimize.threshold, "optimize.threshold")
  balance <- .scalar_logical(balance, "balance")
  stack <- .scalar_logical(stack, "stack")
  status <- .scalar_logical(status, "status")
  folds <- .scalar_integer(folds, "folds", minimum = 1L)
  ts.test <- .scalar_integer(ts.test, "ts.test", minimum = 1L,
                             allow_null = TRUE)
  
  if (!is.null(seed)) {
    seed <- .scalar_integer(seed, "seed", minimum = 0L)
    set.seed(seed)
  }
  
  if (is.null(obj.fn) || !(is.expression(obj.fn) || is.call(obj.fn))) {
    stop("[obj.fn] must be a non-NULL expression or call.", call. = FALSE)
  }
  if (is.expression(obj.fn) && length(obj.fn) != 1L) {
    stop("[obj.fn] must contain exactly one expression.", call. = FALSE)
  }
  
  if (!is.character(objective) || length(objective) != 1L || is.na(objective)) {
    stop("[objective] must be exactly 'min' or 'max'.", call. = FALSE)
  }
  objective <- match.arg(tolower(objective), c("min", "max"))
  
  if (!is.null(type)) {
    if (!is.character(type) || length(type) != 1L || is.na(type)) {
      stop("[type] must be NULL, 'REG', or 'CLASS'.", call. = FALSE)
    }
    type <- match.arg(tolower(type), c("class", "reg"))
  }
  
  if (!is.null(order)) {
    if (is.character(order)) {
      if (length(order) != 1L || tolower(order) != "max") {
        stop("[order] must be NULL, a positive integer, or 'max'.",
             call. = FALSE)
      }
      order <- "max"
    } else {
      order <- .scalar_integer(order, "order", minimum = 1L)
    }
  }
  
  if (!is.numeric(method) || !length(method) || any(!is.finite(method)) ||
      any(method != floor(method))) {
    stop("[method] must contain only 1 and/or 2.", call. = FALSE)
  }
  method <- sort(unique(as.integer(method)))
  if (!all(method %in% c(1L, 2L))) {
    stop("[method] must contain only 1 and/or 2.", call. = FALSE)
  }
  
  if (!is.null(CV.size)) {
    if (!is.numeric(CV.size) || length(CV.size) != 1L ||
        !is.finite(CV.size) || CV.size <= 0 || CV.size >= 1) {
      stop("[CV.size] must be a finite scalar strictly between 0 and 1.",
           call. = FALSE)
    }
    CV.size <- as.numeric(CV.size)
  }
  
  if (!is.null(pred.int)) {
    if (!is.numeric(pred.int) || length(pred.int) != 1L ||
        !is.finite(pred.int) || pred.int <= 0 || pred.int >= 1) {
      stop("[pred.int] must be a finite scalar strictly between 0 and 1.",
           call. = FALSE)
    }
    pred.int <- as.numeric(pred.int)
  }
  
  if (is.null(ncores)) {
    detected <- suppressWarnings(parallel::detectCores())
    if (!is.finite(detected)) detected <- 2L
    ncores <- max(1L, as.integer(detected) - 1L)
  } else {
    ncores <- .scalar_integer(ncores, "ncores", minimum = 1L)
  }
  
  dist <- .nns_reg_validate_dist(dist)
  
  # -------------------------------------------------------------------------
  # Input data and response coding
  # -------------------------------------------------------------------------
  
  x <- .as_train_frame(IVs.train)
  
  if (any(class(DV.train) %in% c("tbl", "data.table"))) {
    DV.train <- as.vector(unlist(DV.train))
  }
  if (is.data.frame(DV.train) || is.matrix(DV.train)) {
    if (NCOL(DV.train) != 1L) {
      stop("[DV.train] must contain exactly one response column.",
           call. = FALSE)
    }
    DV.train <- as.vector(unlist(DV.train))
  }
  
  if (length(DV.train) != nrow(x)) {
    stop("nrow(IVs.train) must equal length(DV.train).", call. = FALSE)
  }
  if (length(DV.train) < 4L) {
    stop("NNS.stack requires at least four training observations.",
         call. = FALSE)
  }
  if (anyNA(DV.train)) {
    stop("[DV.train] contains missing values.", call. = FALSE)
  }
  if ((is.numeric(DV.train) || is.integer(DV.train)) &&
      any(!is.finite(DV.train))) {
    stop("[DV.train] contains non-finite values.", call. = FALSE)
  }
  
  response_was_factor <- is.factor(DV.train)
  response_was_ordered <- is.ordered(DV.train)
  response_was_character <- is.character(DV.train)
  response_was_logical <- is.logical(DV.train)
  response_was_numeric <- is.numeric(DV.train) || is.integer(DV.train)
  
  auto_class <- response_was_factor || response_was_character ||
    response_was_logical ||
    (response_was_numeric && length(unique(DV.train)) == 2L)
  
  # A supplied forecast fold defines a regression task even if the observed
  # numeric response happens to contain only two distinct values. Later values
  # must not switch the task selected at the forecast origin.
  if (auto_class && is.null(type) && is.null(.validation)) type <- "class"
  if (balance && is.null(type)) {
    warning("type = 'CLASS' selected because balance = TRUE.", call. = FALSE)
    type <- "class"
  }
  is_class <- identical(type, "class")
  
  original_response <- DV.train
  class_values <- NULL
  
  if (is_class) {
    if (response_was_factor) {
      response_factor <- droplevels(DV.train)
      class_values <- levels(response_factor)
      y <- as.integer(response_factor)
    } else if (response_was_character) {
      # Sorted (factor) level order, as for a factor response and in NNS.boost.
      class_values <- levels(factor(DV.train))
      y <- match(DV.train, class_values)
    } else if (response_was_logical) {
      class_values <- sort(unique(DV.train))
      y <- match(DV.train, class_values)
    } else if (response_was_numeric) {
      class_values <- sort(unique(as.numeric(DV.train)))
      y <- match(as.numeric(DV.train), class_values)
    } else {
      stop("Unsupported classification response type.", call. = FALSE)
    }
    
    y <- as.numeric(y)
    if (length(unique(y)) < 2L) {
      stop("Classification requires at least two response classes.",
           call. = FALSE)
    }
    if (min(table(y)) < 2L) {
      stop("Each response class requires at least two observations for cross-validation.",
           call. = FALSE)
    }
    
    if (identical(obj.fn, expression(sum((predicted - actual)^2)))) {
      obj.fn <- expression(mean(predicted == actual))
      objective <- "max"
    }
  } else {
    if (!response_was_numeric) {
      stop("A nonnumeric response requires type = 'CLASS'.", call. = FALSE)
    }
    y <- as.numeric(DV.train)
  }
  
  if (balance && !is_class) {
    stop("[balance = TRUE] requires classification.", call. = FALSE)
  }
  
  if (is.null(IVs.test)) {
    z <- x
  } else {
    z <- .as_test_frame(IVs.test, names(x))
  }
  
  aligned <- .align_predictors(x, z)
  x <- aligned$train
  z <- aligned$test
  .check_predictors(x, "IVs.train")
  .check_predictors(z, "IVs.test")
  
  n_obs <- nrow(x)
  original_p <- ncol(x)
  
  if (!is.null(ts.test) && ts.test >= n_obs) {
    stop("[ts.test] must be smaller than the number of training observations.",
         call. = FALSE)
  }
  
  if (original_p == 1L && 2L %in% method) {
    warning("Method 2 was removed because dimension reduction requires more than one original predictor.",
            call. = FALSE)
    method <- setdiff(method, 2L)
    if (!length(method)) method <- 1L
  }
  
  if (2L %in% method) {
    if (is.numeric(dim.red.method)) {
      if (!length(dim.red.method) || any(!is.finite(dim.red.method))) {
        stop("Numeric [dim.red.method] coefficients must be finite.",
             call. = FALSE)
      }
    } else {
      if (!is.character(dim.red.method) || length(dim.red.method) != 1L ||
          is.na(dim.red.method)) {
        stop("[dim.red.method] must be one supported character value or a numeric vector.",
             call. = FALSE)
      }
      dim.red.method <- match.arg(
        tolower(dim.red.method),
        c("cor", "nns.dep", "nns.caus", "equal", "all")
      )
    }
  }
  
  # Regression fits use type = "REG" throughout, including binary responses.
  # The fitting response therefore stays on its observed numeric scale.
  y_fit_all <- y
  
  # -------------------------------------------------------------------------
  # Shared helpers
  # -------------------------------------------------------------------------
  
  .score <- function(predicted, actual) {
    if (length(predicted) != length(actual)) {
      stop("The objective received predicted and actual vectors of different lengths.",
           call. = FALSE)
    }
    value <- eval(obj.fn,
                  envir = list(predicted = predicted, actual = actual),
                  enclos = parent.frame())
    if (!is.numeric(value) || length(value) != 1L) {
      stop("[obj.fn] must return one numeric scalar.", call. = FALSE)
    }
    value <- as.numeric(value)
    if (!is.finite(value)) return(NA_real_)
    value
  }
  
  .sanitize_raw <- function(predicted, fallback_y) {
    predicted <- as.numeric(predicted)
    bad <- !is.finite(predicted)
    if (any(bad)) {
      good <- predicted[!bad]
      replacement <- if (length(good)) gravity(good) else gravity(fallback_y)
      if (!is.finite(replacement)) replacement <- mean(fallback_y)
      if (!is.finite(replacement)) {
        stop("NNS.reg returned no finite predictions.", call. = FALSE)
      }
      predicted[bad] <- replacement
    }
    predicted
  }
  
  .round_codes <- function(raw, threshold) {
    raw <- pmin(pmax(as.numeric(raw), 1), length(class_values))
    lo <- floor(raw)
    hi <- ceiling(raw)
    frac <- raw - lo
    out <- ifelse(frac < threshold, lo, hi)
    as.integer(pmin(pmax(out, 1L), length(class_values)))
  }
  
  .best_threshold <- function(raw, actual) {
    if (!is_class || !optimize.threshold) return(0.5)
    grid <- seq(0.01, 0.99, by = 0.01)
    scores <- vapply(grid, function(th) {
      .score(.round_codes(raw, th), actual)
    }, numeric(1L))
    valid <- which(is.finite(scores))
    if (!length(valid)) return(0.5)
    best_value <- if (objective == "min") {
      min(scores[valid])
    } else {
      max(scores[valid])
    }
    tied <- valid[scores[valid] == best_value]
    grid[tied[ceiling(length(tied) / 2)]]
  }
  
  .evaluate_raw <- function(raw, actual) {
    threshold <- if (is_class) .best_threshold(raw, actual) else 0.5
    predicted <- if (is_class) .round_codes(raw, threshold) else raw
    list(score = .score(predicted, actual), threshold = threshold)
  }
  
  .decode_codes <- function(code) {
    code <- as.integer(pmin(pmax(code, 1L), length(class_values)))
    if (response_was_numeric || response_was_logical) class_values[code] else as.numeric(code)
  }
  
  .decode_interval <- function(interval, threshold) {
    if (is.null(interval)) return(NULL)
    interval <- as.data.frame(interval, check.names = FALSE)
    interval[] <- lapply(interval, function(v) {
      .decode_codes(.round_codes(v, threshold))
    })
    interval
  }
  
  .numeric_interval <- function(interval) {
    if (is.null(interval)) return(NULL)
    interval <- as.data.frame(interval, check.names = FALSE)
    interval[] <- lapply(interval, as.numeric)
    interval
  }
  
  .has_all_classes <- function(train_y) {
    !is_class || identical(sort(unique(train_y)), sort(unique(y)))
  }
  
  .balance_indices <- function(train_y) {
    if (!balance) return(seq_along(train_y))
    groups <- .nns_class_groups(train_y)
    if (length(groups) < 2L || any(lengths(groups) == 0L)) {
      stop("Balancing requires at least two non-empty classes in the fitting split.",
           call. = FALSE)
    }
    smallest <- min(lengths(groups))
    largest <- max(lengths(groups))
    # sample(g, k) on a length-one group samples from 1:g, so index into g.
    down_idx <- unlist(lapply(groups, function(g) {
      g[sample.int(length(g), smallest, replace = FALSE)]
    }), use.names = FALSE)
    up_idx <- unlist(lapply(groups, function(g) {
      g[sample.int(length(g), largest, replace = TRUE)]
    }), use.names = FALSE)
    sample(c(down_idx, up_idx), replace = FALSE)
  }
  
  .numeric_design <- function(train, test, scale = TRUE) {
    train_blocks <- vector("list", ncol(train))
    test_blocks <- vector("list", ncol(train))
    # Original predictor behind each encoded column (factors expand to one
    # column per level), so encoded selections map back to predictor names.
    source_blocks <- vector("list", ncol(train))

    for (j in seq_along(train)) {
      nm <- names(train)[j]
      tr <- train[[j]]
      te <- test[[j]]
      
      if (is.factor(tr)) {
        lev <- if (is.ordered(tr)) levels(tr) else sort(levels(tr))
        tr_chr <- as.character(tr)
        te_chr <- as.character(te)
        tr_block <- vapply(lev, function(level) {
          as.numeric(tr_chr == level)
        }, numeric(length(tr_chr)))
        te_block <- vapply(lev, function(level) {
          as.numeric(te_chr == level)
        }, numeric(length(te_chr)))
        # vapply() drops to a vector for one row or one level; keep rows as
        # observations either way (a single test row has one row per level).
        if (is.null(dim(tr_block))) tr_block <- matrix(tr_block, nrow = length(tr_chr))
        if (is.null(dim(te_block))) te_block <- matrix(te_block, nrow = length(te_chr))
        block_names <- paste0(nm, "__", make.names(lev, unique = TRUE))
        colnames(tr_block) <- block_names
        colnames(te_block) <- block_names
      } else {
        tr_block <- matrix(as.numeric(tr), ncol = 1L,
                           dimnames = list(NULL, nm))
        te_block <- matrix(as.numeric(te), ncol = 1L,
                           dimnames = list(NULL, nm))
      }
      
      train_blocks[[j]] <- tr_block
      test_blocks[[j]] <- te_block
      source_blocks[[j]] <- rep(nm, ncol(tr_block))
    }
    
    train_matrix <- do.call(cbind, train_blocks)
    test_matrix <- do.call(cbind, test_blocks)
    storage.mode(train_matrix) <- "double"
    storage.mode(test_matrix) <- "double"
    colnames(train_matrix) <- make.unique(colnames(train_matrix), sep = "_")
    colnames(test_matrix) <- colnames(train_matrix)

    if (!scale) {
      return(list(train = as.data.frame(train_matrix, check.names = FALSE),
                  test = as.data.frame(test_matrix, check.names = FALSE)))
    }
    
    train_min <- apply(train_matrix, 2L, min)
    train_max <- apply(train_matrix, 2L, max)
    train_range <- train_max - train_min
    train_range[!is.finite(train_range) | train_range == 0] <- 1
    
    train_scaled <- sweep(train_matrix, 2L, train_min, "-")
    train_scaled <- sweep(train_scaled, 2L, train_range, "/")
    test_scaled <- sweep(test_matrix, 2L, train_min, "-")
    test_scaled <- sweep(test_scaled, 2L, train_range, "/")
    
    train_scaled <- as.data.frame(train_scaled, check.names = FALSE)
    test_scaled <- as.data.frame(test_scaled, check.names = FALSE)
    
    list(train = train_scaled, test = test_scaled,
         minimum = train_min, range = train_range,
         source = unlist(source_blocks, use.names = FALSE))
  }
  
  # A forecast caller may supply a training prefix completed using only its
  # own history and deployment-generated validation predictors. Actual future
  # responses are used solely for scoring. The final model still fits x/y.
  x.cv <- x; y.cv <- y
  validation.rows <- NULL
  if (!is.null(.validation)) {
    if (is_class || is.null(ts.test) || folds != 1L || !is.null(CV.size))
      stop("[.validation] requires regression with ts.test, folds = 1 and CV.size = NULL.")
    required <- c("IVs.train", "DV.train", "IVs.test", "DV.test")
    if (!is.list(.validation) || !all(required %in% names(.validation)))
      stop("[.validation] must provide IVs.train, DV.train, IVs.test and DV.test.")
    vt <- .as_test_frame(.validation$IVs.train, names(x))
    vv <- .as_test_frame(.validation$IVs.test, names(x))
    va <- .align_predictors(vt, vv)
    vt <- va$train; vv <- va$test
    .check_predictors(vt, ".validation$IVs.train")
    .check_predictors(vv, ".validation$IVs.test")
    yt <- as.numeric(.validation$DV.train); yv <- as.numeric(.validation$DV.test)
    prefix <- n_obs - ts.test
    if (nrow(vt) != prefix || nrow(vv) < 1L || nrow(vv) > ts.test ||
        length(yt) != prefix || length(yv) != nrow(vv) ||
        any(!is.finite(c(yt, yv))))
      stop("[.validation] needs N-ts.test finite training rows and 1..ts.test finite held-out rows.")
    validation.rows <- prefix + seq_len(nrow(vv))
    x.cv[seq_len(prefix), ] <- vt
    x.cv[validation.rows, ] <- vv
    y.cv[seq_len(prefix)] <- yt
    y.cv[validation.rows] <- yv
  }
  y.fit.cv <- y.cv

  .make_splits <- function() {
    if (!is.null(validation.rows))
      return(list(list(train = seq_len(n_obs - ts.test), validation = validation.rows)))
    all_index <- seq_len(n_obs)
    
    if (!is.null(ts.test)) {
      possible <- floor((n_obs - 1L) / ts.test)
      if (possible < 1L) {
        stop("Not enough observations for the requested [ts.test].",
             call. = FALSE)
      }
      use_folds <- min(folds, possible)
      if (use_folds < folds) {
        warning(sprintf(
          "Only %d non-overlapping chronological fold(s) are available.",
          use_folds
        ), call. = FALSE)
      }
      starts <- n_obs - (use_folds:1L) * ts.test + 1L
      out <- lapply(starts, function(start) {
        validation <- seq.int(start, start + ts.test - 1L)
        training <- seq_len(start - 1L)
        list(train = training, validation = validation)
      })
      keep <- vapply(out, function(s) {
        length(s$train) >= 3L && .has_all_classes(y[s$train])
      }, logical(1L))
      out <- out[keep]
      if (!length(out)) {
        stop(paste0(
          "No chronological fold retained enough training observations and ",
          "all response classes."
        ), call. = FALSE)
      }
      return(out)
    }
    
    # Historical compatibility: folds = 1 means one repeated holdout even when
    # CV.size is omitted. The original implementation drew a validation
    # fraction between 0.20 and 1/3, so retain that behavior under the local
    # seed while still keeping validation observations completely unbalanced.
    holdout_size <- CV.size
    if (is.null(holdout_size) && folds == 1L) {
      holdout_size <- round(stats::runif(1L, 0.20, 1 / 3), 3L)
    }
    
    if (!is.null(holdout_size)) {
      out <- vector("list", folds)
      for (b in seq_len(folds)) {
        if (is_class) {
          groups <- .nns_class_groups(y)
          validation <- unlist(lapply(groups, function(g) {
            size <- min(length(g) - 1L,
                        max(1L, as.integer(round(holdout_size * length(g)))))
            if (size <= 0L) integer() else sample(g, size, replace = FALSE)
          }), use.names = FALSE)
          validation <- sort(unique(validation))
        } else {
          size <- max(1L, min(n_obs - 1L,
                              as.integer(round(holdout_size * n_obs))))
          validation <- sort(sample.int(n_obs, size, replace = FALSE))
        }
        training <- setdiff(all_index, validation)
        if (length(training) < 3L || !.has_all_classes(y[training])) {
          stop(paste0(
            "Unable to create a repeated holdout retaining enough fitting ",
            "observations and every response class."
          ), call. = FALSE)
        }
        out[[b]] <- list(train = training, validation = validation)
      }
      return(out)
    }
    
    use_folds <- min(folds, n_obs)
    if (is_class) {
      class_counts <- table(y)
      if (min(class_counts) < 2L) {
        stop("Each response class requires at least two observations for cross-validation.",
             call. = FALSE)
      }
      use_folds <- min(use_folds, max(class_counts))
    }
    if (use_folds < 2L) {
      stop("At least two folds are required when [CV.size] and [ts.test] are NULL.",
           call. = FALSE)
    }
    if (use_folds < folds) {
      warning(sprintf("Cross-validation folds reduced to %d for the available data.",
                      use_folds), call. = FALSE)
    }
    
    fold_id <- integer(n_obs)
    if (is_class) {
      groups <- .nns_class_groups(y)
      for (g in groups) {
        shuffled <- sample(g, length(g), replace = FALSE)
        fold_id[shuffled] <- rep(seq_len(use_folds), length.out = length(g))
      }
    } else {
      shuffled <- sample(all_index, n_obs, replace = FALSE)
      fold_id[shuffled] <- rep(seq_len(use_folds), length.out = n_obs)
    }
    
    out <- lapply(seq_len(use_folds), function(b) {
      validation <- which(fold_id == b)
      training <- setdiff(all_index, validation)
      list(train = training, validation = validation)
    })
    keep <- vapply(out, function(s) {
      length(s$validation) > 0L && length(s$train) >= 3L &&
        .has_all_classes(y[s$train])
    }, logical(1L))
    out <- out[keep]
    if (length(out) < 2L) {
      stop("Unable to create at least two valid cross-validation folds.",
           call. = FALSE)
    }
    out
  }
  
  splits <- .make_splits()

  if (is_class) {
    return(.nns_stack_classify(x, y, z, class_values, splits, method, stack,
      dim.red.method, order, dist, ncores, optimize.threshold, pred.int,
      .score, objective, .balance_indices,
      response_was_numeric || response_was_logical, status, .numeric_design,
      tau = if (is.null(ts.test)) NULL else "ts"))
  }
  
  .coefficient_vector <- function(X, response) {
    X <- as.matrix(X)
    p <- ncol(X)
    
    if (is.numeric(dim.red.method)) {
      coef <- as.numeric(dim.red.method)
      if (!is.null(names(dim.red.method))) {
        if (!setequal(names(dim.red.method), colnames(X))) {
          stop(paste0(
            "Named numeric [dim.red.method] coefficients must exactly match ",
            "the encoded design columns."
          ), call. = FALSE)
        }
        coef <- as.numeric(dim.red.method[colnames(X)])
      } else if (length(coef) != p) {
        stop(sprintf(
          "Numeric [dim.red.method] must contain %d encoded coefficients.", p
        ), call. = FALSE)
      }
      coef[!is.finite(coef)] <- 0
      return(coef)
    }
    
    cor_coef <- function() {
      out <- vapply(seq_len(p), function(j) {
        suppressWarnings(stats::cor(X[, j], response, method = "spearman"))
      }, numeric(1L))
      out[!is.finite(out)] <- 0
      out
    }
    
    dep_coef <- function() {
      out <- vapply(seq_len(p), function(j) {
        tryCatch(
          as.numeric(NNS.dep(X[, j], response,
                             print.map = FALSE, asym = TRUE)$Dependence)[1L],
          error = function(e) 0
        )
      }, numeric(1L))
      out[!is.finite(out)] <- 0
      out
    }
    
    caus_coef <- function() {
      tau_value <- if (is.null(ts.test)) "cs" else "ts"
      out <- vapply(seq_len(p), function(j) {
        tryCatch(
          as.numeric(Uni.caus(response, X[, j],
                              tau = tau_value, plot = FALSE))[1L],
          error = function(e) 0
        )
      }, numeric(1L))
      out[!is.finite(out)] <- 0
      out
    }
    
    coef <- switch(
      dim.red.method,
      "cor" = cor_coef(),
      "nns.dep" = dep_coef(),
      "nns.caus" = caus_coef(),
      "equal" = rep(1, p),
      "all" = rowMeans(cbind(caus_coef(), dep_coef(), cor_coef(), rep(1, p))),
      stop("Unsupported [dim.red.method].", call. = FALSE)
    )
    
    coef[!is.finite(coef)] <- 0
    if (!any(abs(coef) > 0)) coef <- rep(1, p)
    coef
  }
  
  .active_coefficients <- function(coef, count) {
    coef <- as.numeric(coef)
    count <- max(1L, min(as.integer(count), length(coef)))
    ord <- order(abs(coef), decreasing = TRUE, na.last = NA, method = "radix")
    active <- ord[seq_len(min(count, length(ord)))]
    out <- rep(0, length(coef))
    out[active] <- coef[active]
    if (!any(abs(out) > 0)) {
      out[active] <- 1
    }
    out
  }
  
  # Method 1 keeps the actual coordinates ranked first by the dimension
  # reduction coefficients. The rank, not a nonzero fold coefficient, selects
  # them: a predictor that is constant in one fold has a zero coefficient
  # there, and dropping it would give that fold a different (univariate)
  # model from the other folds and from the final fit. A constant column
  # adds nothing to the NNS distance, whose coordinates are range-scaled.
  .active_columns <- function(coef, count) {
    coef <- as.numeric(coef)
    count <- max(1L, min(as.integer(count), length(coef)))
    ord <- order(abs(coef), decreasing = TRUE, na.last = NA, method = "radix")
    sort(ord[seq_len(min(count, length(ord)))])
  }
  
  .project_xstar <- function(train_design, test_design, coef) {
    denom <- sum(abs(coef) > 0)
    if (denom < 1L) stop("No active dimension-reduction coefficients.",
                         call. = FALSE)
    list(
      train = as.numeric(as.matrix(train_design) %*% coef / denom),
      test = as.numeric(as.matrix(test_design) %*% coef / denom)
    )
  }
  
  .xstar_path <- function(train_design, test_design, coef) {
    ord <- order(abs(coef), decreasing = TRUE, na.last = NA, method = "radix")
    if (isTRUE(getOption("NNS.native.stack", TRUE))) {
      tryCatch(NNS_xstar_path_cpp(as.matrix(train_design), as.matrix(test_design),
                                  as.numeric(coef), as.integer(ord), as.integer(ncores)),
               error = function(e) NULL)
    } else NULL
  }
  
  .fit_univariate_raw <- function(train_x, train_y_fit, test_x,
                                  confidence.interval = NULL,
                                  point.only = TRUE,
                                  allow_failure = FALSE) {
    fit <- tryCatch(
      suppressWarnings({
        if (point.only && isTRUE(getOption("NNS.native.univariate", TRUE))) {
          fast <- .nns_reg_univariate_fast(as.numeric(train_x), as.numeric(train_y_fit),
                                           as.numeric(test_x), order = order,
                                           noise.reduction = "off", is.class = FALSE)
          list(Point.est = fast$prediction)
        } else {
          NNS.reg(
            as.numeric(train_x),
            as.numeric(train_y_fit),
            point.est = as.numeric(test_x),
            plot = FALSE,
            residual.plot = FALSE,
            order = order,
            type = "REG",
            factor.2.dummy = FALSE,
            dist = dist,
            ncores = ncores,
            point.only = point.only,
            confidence.interval = confidence.interval
          )
        }
      }),
      error = function(e) {
        if (allow_failure) return(NULL)
        stop(e)
      }
    )
    if (is.null(fit)) {
      return(list(raw = rep(NA_real_, length(test_x)), fit = NULL))
    }
    raw <- .sanitize_raw(as.numeric(fit$Point.est), train_y_fit)
    list(raw = raw, fit = fit)
  }
  
  
  # Score every k with exactly the estimator the final NNS.reg fit uses:
  # NNS_mreg_predict_path_cpp implements the repaired multivariate prediction
  # rule (range-normalized metric, stable ties, ensemble weights) for
  # k = 1..kmax. The repaired NNS.M.reg no longer extrapolates outside the
  # training support, so no gradient extension is applied here either.
  .production_multivariate_path <- function(rpm, Xtest, train_design, kmax = NULL) {
    Xtest <- as.data.frame(Xtest, check.names = FALSE)
    feature_names <- setdiff(names(rpm), "y.hat")
    Xtest <- Xtest[, feature_names, drop = FALSE]
    train_design <- as.data.frame(train_design, check.names = FALSE)
    train_design <- train_design[, feature_names, drop = FALSE]
    if (is.null(kmax)) kmax <- nrow(rpm)
    kmax <- min(kmax, nrow(rpm))
    
    rpm_x <- as.matrix(rpm[, feature_names, drop = FALSE])
    storage.mode(rpm_x) <- "double"
    test_matrix <- as.matrix(Xtest)
    storage.mode(test_matrix) <- "double"
    minimums <- vapply(train_design, min, numeric(1L))
    maximums <- vapply(train_design, max, numeric(1L))
    dist_code <- match(dist, c("NNS", "L2", "L1", "FACTOR")) - 1L
    
    path <- if (isTRUE(getOption("NNS.native.stack", TRUE))) {
      NNS_mreg_predict_path_v2_cpp(
        rpm_x, as.numeric(rpm$y.hat), test_matrix, as.integer(kmax),
        dist_code, as.numeric(minimums), as.numeric(maximums), FALSE,
        as.integer(ncores)
      )
    } else {
      NNS_mreg_predict_path_cpp(
        rpm_x, as.numeric(rpm$y.hat), test_matrix, as.integer(kmax),
        dist_code, as.numeric(minimums), as.numeric(maximums), FALSE
      )
    }
    if (nrow(path) != nrow(test_matrix)) {
      stop("The production distance path returned an invalid row count.",
           call. = FALSE)
    }
    path
  }
  
  .candidate_from_oof <- function(sum_matrix, count_matrix, candidate) {
    count <- count_matrix[, candidate]
    valid <- count > 0L
    raw <- rep(NA_real_, n_obs)
    raw[valid] <- sum_matrix[valid, candidate] / count[valid]
    valid <- valid & is.finite(raw)
    if (!any(valid)) {
      return(list(score = NA_real_, threshold = 0.5, raw = raw))
    }
    evaluation <- .evaluate_raw(raw[valid], y.cv[valid])
    list(score = evaluation$score,
         threshold = evaluation$threshold,
         raw = raw)
  }
  
  .select_best <- function(scores) {
    valid <- which(is.finite(scores))
    if (!length(valid)) {
      stop("No candidate produced a finite out-of-fold objective.",
           call. = FALSE)
    }
    best_value <- if (objective == "min") {
      min(scores[valid])
    } else {
      max(scores[valid])
    }
    tied <- valid[scores[valid] == best_value]
    as.integer(tied[ceiling(length(tied) / 2)])
  }
  
  # Full-data encoded design establishes the fixed encoded column domain.
  full_design <- .numeric_design(x, z)
  encoded_p <- ncol(full_design$train)
  
  if (2L %in% method && is.numeric(dim.red.method) &&
      is.null(names(dim.red.method)) && length(dim.red.method) != encoded_p) {
    stop(sprintf(
      "Numeric [dim.red.method] must contain %d encoded coefficients.",
      encoded_p
    ), call. = FALSE)
  }
  
  # -------------------------------------------------------------------------
  # Method 2: select active dimension count from OOF predictions
  # -------------------------------------------------------------------------
  
  dim_best_count <- NA_integer_
  dim_best_score <- NA_real_
  dim_component_threshold <- 0.5
  dim_oof_raw <- rep(NA_real_, n_obs)
  dim_threshold_report <- NA_real_
  dim_active_variables <- NULL
  dim_coefficients_report <- NULL
  dim_full_coef <- NULL
  dim_full_xstar_train <- NULL
  dim_full_xstar_test <- NULL
  
  if (2L %in% method) {
    dim_sum <- matrix(0, nrow = n_obs, ncol = encoded_p)
    dim_count <- matrix(0L, nrow = n_obs, ncol = encoded_p)
    
    for (b in seq_along(splits)) {
      split <- splits[[b]]
      train_idx <- split$train
      valid_idx <- split$validation
      fold_design <- .numeric_design(
        x.cv[train_idx, , drop = FALSE],
        x.cv[valid_idx, , drop = FALSE]
      )
      coef_fold <- .coefficient_vector(fold_design$train, y.cv[train_idx])
      balanced_idx <- .balance_indices(y.cv[train_idx])
      
      if (status) message(sprintf("Method 2 fold %d/%d: generating %d cumulative projections", b, length(splits), encoded_p))
      native_path <- .xstar_path(fold_design$train, fold_design$test, coef_fold)
      representatives <- if (!is.null(native_path)) as.integer(native_path$representative) else seq_len(encoded_p)
      unique_candidates <- unique(representatives)
      if (status) message(sprintf("Method 2 fold %d/%d: evaluating %d unique candidates", b, length(splits), length(unique_candidates)))
      candidate_raw <- vector("list", encoded_p)
      for (m in unique_candidates) {
        if (!is.null(native_path)) {
          projected <- list(train = native_path$train[, m], test = native_path$test[, m])
        } else {
          active_coef <- .active_coefficients(coef_fold, m)
          projected <- .project_xstar(fold_design$train, fold_design$test, active_coef)
        }
        fit <- .fit_univariate_raw(projected$train[balanced_idx],
                                   y.fit.cv[train_idx][balanced_idx],
                                   projected$test,
                                   point.only = TRUE,
                                   allow_failure = TRUE)
        candidate_raw[[m]] <- fit$raw
      }
      for (m in seq_len(encoded_p)) {
        raw <- candidate_raw[[representatives[m]]]
        good <- is.finite(raw)
        if (any(good)) {
          rows <- valid_idx[good]
          dim_sum[rows, m] <- dim_sum[rows, m] + raw[good]
          dim_count[rows, m] <- dim_count[rows, m] + 1L
        }
      }
      if (status) message(sprintf("Method 2 fold %d/%d complete", b, length(splits)))
    }
    
    dim_scores <- rep(NA_real_, encoded_p)
    dim_thresholds <- rep(0.5, encoded_p)
    dim_raw_candidates <- vector("list", encoded_p)
    
    for (m in seq_len(encoded_p)) {
      candidate <- .candidate_from_oof(dim_sum, dim_count, m)
      dim_scores[m] <- candidate$score
      dim_thresholds[m] <- candidate$threshold
      dim_raw_candidates[[m]] <- candidate$raw
      if (status) {
        message(sprintf(
          paste0("Current dimension count = %d | OOF eval(obj.fn) = %s | ",
                 "Iterations remaining = %d"),
          m,
          if (is.finite(dim_scores[m]))
            format(dim_scores[m], digits = 6) else "NA",
          encoded_p - m
        ))
      }
    }
    
    dim_best_count <- .select_best(dim_scores)
    dim_best_score <- dim_scores[dim_best_count]
    dim_component_threshold <- dim_thresholds[dim_best_count]
    dim_oof_raw <- dim_raw_candidates[[dim_best_count]]
    
    dim_full_coef_original <- .coefficient_vector(full_design$train, y)
    dim_full_coef <- .active_coefficients(dim_full_coef_original,
                                          dim_best_count)
    dim_full_projection <- .xstar_path(full_design$train, full_design$test,
                                       dim_full_coef)
    if (is.null(dim_full_projection)) {
      dim_full_projection <- .project_xstar(
        full_design$train,
        full_design$test,
        dim_full_coef
      )
      dim_full_xstar_train <- dim_full_projection$train
      dim_full_xstar_test <- dim_full_projection$test
    } else {
      dim_full_xstar_train <- dim_full_projection$train[, dim_best_count]
      dim_full_xstar_test <- dim_full_projection$test[, dim_best_count]
    }
    
    active_magnitudes <- abs(dim_full_coef[abs(dim_full_coef) > 0])
    dim_threshold_report <- if (dim_best_count >= length(dim_full_coef)) {
      0
    } else if (length(active_magnitudes)) {
      min(active_magnitudes)
    } else {
      0
    }
    if (!is.finite(dim_threshold_report)) dim_threshold_report <- 0

    # The exact predictors carried by the final X* projection (and therefore
    # by Method 1 as well when stack = TRUE), ranked by |coefficient|. This is
    # the authoritative selection: a threshold comparison cannot reproduce it
    # because ties at the boundary are broken by column order.
    dim_coefficients_report <- setNames(as.numeric(dim_full_coef),
                                        names(full_design$train))
    active_order <- order(abs(dim_full_coef), decreasing = TRUE,
                          method = "radix")
    active_order <- active_order[abs(dim_full_coef[active_order]) > 0]
    dim_active_variables <- unique(full_design$source[active_order])
  }
  
  # -------------------------------------------------------------------------
  # Method 1: bounded small-k search + mandatory all-points candidate
  # -------------------------------------------------------------------------
  
  reg_best_k <- NA_integer_
  reg_best_score <- NA_real_
  reg_component_threshold <- 0.5
  reg_oof_raw <- rep(NA_real_, n_obs)
  
  .method1_design_for_split <- function(train_idx, valid_idx) {
    fold_design <- .numeric_design(
      x.cv[train_idx, , drop = FALSE],
      x.cv[valid_idx, , drop = FALSE]
    )
    
    if (stack && 2L %in% method) {
      coef_fold <- .coefficient_vector(fold_design$train, y.cv[train_idx])
      selected <- .active_columns(coef_fold, dim_best_count)
      list(train = fold_design$train[, selected, drop = FALSE],
           test = fold_design$test[, selected, drop = FALSE])
    } else {
      list(train = fold_design$train, test = fold_design$test)
    }
  }
  
  if (1L %in% method) {
    # Intended NNS.stack search geometry:
    #
    #   local candidates = 1:floor(sqrt(n))
    #   limit candidate  = ALL regression points
    #
    # Every local candidate is first evaluated across every fold. The
    # diminishing-returns stop is then applied to the complete pooled OOF
    # objectives. This prevents fold-specific early stopping from giving larger
    # candidates partial or zero OOF coverage.
    # A single predictor's NNS.reg fit has no neighbour count to tune (it
    # ignores n.best), so ALL, the deployed fit, is its only candidate.
    univariate <- encoded_p == 1L || (stack && 2L %in% method && dim_best_count == 1L)
    l <- if (univariate) 0L else max(1L, floor(sqrt(n_obs)))
    candidate_ids <- c(as.character(seq_len(l)), "all")
    
    sum_list <- setNames(vector("list", length(candidate_ids)), candidate_ids)
    count_list <- setNames(vector("list", length(candidate_ids)), candidate_ids)
    for (id in candidate_ids) {
      sum_list[[id]] <- rep(0, n_obs)
      count_list[[id]] <- rep(0L, n_obs)
    }
    
    fold_small_kmax <- integer(length(splits))
    
    for (b in seq_along(splits)) {
      split <- splits[[b]]
      train_idx <- split$train
      valid_idx <- split$validation
      
      if (status) {
        message(sprintf(
          "Method 1 fold %d/%d: preparing fold design",
          b, length(splits)
        ))
      }
      
      design <- .method1_design_for_split(train_idx, valid_idx)
      balanced_idx <- .balance_indices(y.cv[train_idx])
      train_design <- design$train[balanced_idx, , drop = FALSE]
      train_y_fit <- y.fit.cv[train_idx][balanced_idx]
      valid_design <- design$test
      
      if (ncol(train_design) == 1L) {
        train_x <- as.numeric(train_design[[1L]])
        test_x <- as.numeric(valid_design[[1L]])
        
        if (status) {
          message(sprintf(
            "Method 1 fold %d/%d: univariate NNS.reg (%d observations)",
            b, length(splits), length(train_x)
          ))
        }
        
        all_raw <- .fit_univariate_raw(train_x, train_y_fit, test_x)$raw
        good <- is.finite(all_raw)
        if (any(good)) {
          rows <- valid_idx[good]
          sum_list[["all"]][rows] <-
            sum_list[["all"]][rows] + all_raw[good]
          count_list[["all"]][rows] <-
            count_list[["all"]][rows] + 1L
        }
        
      } else {
        if (status) {
          message(sprintf(
            "Method 1 fold %d/%d: building partitions",
            b, length(splits)
          ))
        }
        
        setup <- .nns_mreg_prepare_model(
          train_design,
          train_y_fit,
          order = order,
          noise.reduction = "off",
          is.class = FALSE,
          use.native = isTRUE(getOption("NNS.native.mreg", TRUE))
        )
        rpm <- setup$RPM
        
        if (is.null(rpm) || !is.data.frame(rpm) ||
            nrow(rpm) < 1L || !"y.hat" %in% names(rpm)) {
          stop(
            "NNS.reg did not return a usable regression-point matrix.",
            call. = FALSE
          )
        }
        
        nRPM <- nrow(rpm)
        small_kmax <- min(l, nRPM)
        fold_small_kmax[b] <- small_kmax
        
        if (status) {
          message(sprintf(
            paste0(
              "Method 1 fold %d/%d: RPM rows = %d; validation rows = %d; ",
              "local candidates = 1...%d; limit candidate = ALL (%d)"
            ),
            b, length(splits), nRPM, length(valid_idx),
            small_kmax, nRPM
          ))
        }
        
        small_path <- .production_multivariate_path(
          rpm = rpm,
          Xtest = valid_design,
          train_design = train_design,
          kmax = small_kmax
        )
        
        for (k in seq_len(small_kmax)) {
          id <- as.character(k)
          raw <- .sanitize_raw(
            small_path[, k],
            y.cv[train_idx]
          )
          good <- is.finite(raw)
          if (any(good)) {
            rows <- valid_idx[good]
            sum_list[[id]][rows] <-
              sum_list[[id]][rows] + raw[good]
            count_list[[id]][rows] <-
              count_list[[id]][rows] + 1L
          }
        }
        
        # The ALL candidate is always populated for every fold. Score the
        # estimator deployed when ALL wins, NNS.reg(n.best = "all"), from the fold RPM.
        all_raw <- .sanitize_raw(
          .nns_mreg_predict(
            valid_design, rpm, nRPM, dist,
            setup$minimums, setup$maximums, FALSE, ncores
          ),
          y.cv[train_idx]
        )
        good <- is.finite(all_raw)
        if (any(good)) {
          rows <- valid_idx[good]
          sum_list[["all"]][rows] <-
            sum_list[["all"]][rows] + all_raw[good]
          count_list[["all"]][rows] <-
            count_list[["all"]][rows] + 1L
        }
      }
      
      if (status) {
        message(sprintf(
          "Method 1 fold %d/%d complete",
          b, length(splits)
        ))
      }
    }
    
    common_small_kmax <- min(fold_small_kmax)
    if (!univariate && (!is.finite(common_small_kmax) || common_small_kmax < 1L)) {
      stop(
        "No Method 1 local candidate was available in every fold.",
        call. = FALSE
      )
    }
    
    candidate_scores <- setNames(
      rep(NA_real_, length(candidate_ids)),
      candidate_ids
    )
    candidate_thresholds <- setNames(
      rep(0.5, length(candidate_ids)),
      candidate_ids
    )
    candidate_raws <- setNames(
      vector("list", length(candidate_ids)),
      candidate_ids
    )
    
    # The first candidate is evaluated in every valid Method 1 fold. Its count
    # vector defines the required complete OOF coverage pattern. A candidate
    # may compete only when it has exactly the same coverage.
    reference_count <- count_list[[candidate_ids[1L]]]
    
    .score_method1_candidate <- function(id) {
      sum_vec <- sum_list[[id]]
      count_vec <- count_list[[id]]
      
      raw <- rep(NA_real_, n_obs)
      covered <- count_vec > 0L
      raw[covered] <- sum_vec[covered] / count_vec[covered]
      candidate_raws[[id]] <<- raw
      
      complete_coverage <- identical(
        as.integer(count_vec),
        as.integer(reference_count)
      )
      valid <- covered & is.finite(raw)
      
      if (!complete_coverage || !any(valid)) {
        candidate_scores[id] <<- NA_real_
        candidate_thresholds[id] <<- 0.5
        return(FALSE)
      }
      
      evaluation <- .evaluate_raw(raw[valid], y.cv[valid])
      candidate_scores[id] <<-
        unname(as.numeric(evaluation$score))
      candidate_thresholds[id] <<-
        unname(as.numeric(evaluation$threshold))
      
      is.finite(candidate_scores[id])
    }
    
    evaluated_small_ids <- character()
    
    # Apply diminishing marginal returns only after each candidate has complete
    # pooled OOF predictions. This is the statistically comparable stopping
    # rule that the fold-local implementation was trying to approximate.
    for (k in seq_len(common_small_kmax)) {
      id <- as.character(k)
      usable <- .score_method1_candidate(id)
      
      if (!usable) {
        if (status) {
          message(sprintf(
            paste0(
              "Method 1 local candidate k = %d lacks complete OOF coverage; ",
              "stopping the local search"
            ),
            k
          ))
        }
        break
      }
      
      evaluated_small_ids <- c(evaluated_small_ids, id)
      
      if (status) {
        message(sprintf(
          paste0(
            "Current NNS.reg(..., n.best = %d) | OOF eval(obj.fn) = %s | ",
            "local iterations remaining = %d"
          ),
          k,
          format(candidate_scores[id], digits = 6),
          common_small_kmax - k
        ))
      }
      
      if (length(evaluated_small_ids) >= 4L) {
        recent_ids <- tail(evaluated_small_ids, 3L)
        recent <- as.numeric(candidate_scores[recent_ids])
        
        stop_local <- if (objective == "min") {
          recent[3L] >= recent[2L] &&
            recent[3L] >= recent[1L]
        } else {
          recent[3L] <= recent[2L] &&
            recent[3L] <= recent[1L]
        }
        
        if (stop_local) {
          if (status) {
            message(sprintf(
              paste0(
                "Method 1 local search stopped at k = %d; ",
                "ALL remains eligible"
              ),
              k
            ))
          }
          break
        }
      }
    }
    
    # ALL is a separate limit condition. It is always scored after the local
    # sequence and is never subject to the diminishing-returns stop.
    all_usable <- .score_method1_candidate("all")
    if (status) {
      message(sprintf(
        "Current NNS.reg(..., n.best = ALL) | OOF eval(obj.fn) = %s",
        if (all_usable) {
          format(candidate_scores["all"], digits = 6)
        } else {
          "NA (incomplete OOF coverage)"
        }
      ))
    }
    
    eligible_ids <- evaluated_small_ids
    if (all_usable) eligible_ids <- c(eligible_ids, "all")
    eligible_ids <- eligible_ids[
      is.finite(candidate_scores[eligible_ids])
    ]
    
    if (!length(eligible_ids)) {
      stop(
        "No Method 1 candidate produced a finite complete-coverage OOF objective.",
        call. = FALSE
      )
    }
    
    best_val <- if (objective == "min") {
      min(candidate_scores[eligible_ids])
    } else {
      max(candidate_scores[eligible_ids])
    }
    best_ids <- eligible_ids[
      candidate_scores[eligible_ids] == best_val
    ]
    
    # Preserve this version's first-candidate tie rule.
    best_id <- best_ids[1L]
    
    if (identical(best_id, "all")) {
      reg_best_k <- NA_integer_
      reg_best_label <- "all"
    } else {
      reg_best_k <- as.integer(best_id)
      reg_best_label <- "integer"
    }
    
    reg_best_score <-
      unname(as.numeric(candidate_scores[best_id]))
    reg_component_threshold <-
      unname(as.numeric(candidate_thresholds[best_id]))
    reg_oof_raw <- candidate_raws[[best_id]]
    
    .reg_best_id <- best_id
    .reg_best_label <- reg_best_label
    
    if (status) {
      if (identical(best_id, "all")) {
        message(sprintf(
          paste0(
            "Best Method 1 candidate: ALL (all RPM rows), ",
            "score = %s"
          ),
          format(reg_best_score, digits = 6)
        ))
      } else {
        message(sprintf(
          "Best Method 1 candidate: k = %d, score = %s",
          reg_best_k,
          format(reg_best_score, digits = 6)
        ))
      }
    }
  } else {
    .reg_best_id <- NA_character_
    .reg_best_label <- NA_character_
  }
  
  # -------------------------------------------------------------------------
  # Optimize the actual OOF blend and its final classification threshold
  # -------------------------------------------------------------------------
  
  component_weights <- c(reg = 0, dim.red = 0)
  probability.threshold <- 0.5
  
  if (identical(method, 1L)) {
    component_weights["reg"] <- 1
    probability.threshold <- reg_component_threshold
  } else if (identical(method, 2L)) {
    component_weights["dim.red"] <- 1
    probability.threshold <- dim_component_threshold
  } else {
    valid <- is.finite(reg_oof_raw) & is.finite(dim_oof_raw)
    if (!any(valid)) {
      stop("The two component models have no common finite OOF predictions.",
           call. = FALSE)
    }
    
    weight_grid <- seq(0, 1, by = 0.01)
    blend_scores <- rep(NA_real_, length(weight_grid))
    blend_thresholds <- rep(0.5, length(weight_grid))
    
    for (i in seq_along(weight_grid)) {
      w <- weight_grid[i]
      raw <- w * reg_oof_raw[valid] + (1 - w) * dim_oof_raw[valid]
      evaluation <- .evaluate_raw(raw, y.cv[valid])
      blend_scores[i] <- evaluation$score
      blend_thresholds[i] <- evaluation$threshold
    }
    
    valid_grid <- which(is.finite(blend_scores))
    if (!length(valid_grid)) {
      stop("No ensemble weight produced a finite OOF objective.",
           call. = FALSE)
    }
    best_value <- if (objective == "min") {
      min(blend_scores[valid_grid])
    } else {
      max(blend_scores[valid_grid])
    }
    tied <- valid_grid[blend_scores[valid_grid] == best_value]
    selected_index <- as.integer(tied[ceiling(length(tied) / 2)])
    selected_weight <- weight_grid[selected_index]
    
    component_weights <- c(reg = selected_weight,
                           dim.red = 1 - selected_weight)
    probability.threshold <- blend_thresholds[selected_index]
  }
  
  # -------------------------------------------------------------------------
  # Final production fits on complete training data
  # -------------------------------------------------------------------------
  
  if (status) message("Generating final estimates")
  
  reg_raw_final <- NULL
  reg_pred_int_raw <- NULL
  dim_raw_final <- NULL
  dim_pred_int_raw <- NULL
  
  if (2L %in% method) {
    balanced_idx <- .balance_indices(y)
    dim_final_fit <- .fit_univariate_raw(
      dim_full_xstar_train[balanced_idx],
      y_fit_all[balanced_idx],
      dim_full_xstar_test,
      confidence.interval = pred.int,
      point.only = FALSE
    )
    dim_raw_final <- dim_final_fit$raw
    dim_pred_int_raw <- .numeric_interval(dim_final_fit$fit$pred.int)
  }
  
  .method1_full_design <- function() {
    if (stack && 2L %in% method) {
      selected <- .active_columns(dim_full_coef_original, dim_best_count)
      list(train = full_design$train[, selected, drop = FALSE],
           test = full_design$test[, selected, drop = FALSE])
    } else {
      list(train = full_design$train, test = full_design$test)
    }
  }
  
  if (1L %in% method) {
    final_design <- .method1_full_design()
    balanced_idx <- .balance_indices(y)
    train_design <- final_design$train[balanced_idx, , drop = FALSE]
    train_y_fit <- y_fit_all[balanced_idx]
    test_design <- final_design$test
    
    # Determine n.best for final fit
    if (.reg_best_label == "all") {
      # For all candidate, we need n.best = "all" (or numeric nrow(RPM))
      # We'll use n.best = "all" in NNS.reg
      n.best <- "all"
    } else {
      n.best <- reg_best_k
    }
    
    # Only the point estimates, their interval and the RPM are read from the
    # final fit, all of which a point-only fit returns.
    if (ncol(train_design) == 1L) {
      reg_final_fit <- suppressWarnings(
        NNS.reg(
          as.numeric(train_design[[1L]]),
          as.numeric(train_y_fit),
          point.est = as.numeric(test_design[[1L]]),
          plot = FALSE,
          residual.plot = FALSE,
          order = order,
          type = "REG",
          factor.2.dummy = FALSE,
          dist = dist,
          ncores = ncores,
          point.only = TRUE,
          confidence.interval = pred.int
        )
      )
      reg_raw_final <- .sanitize_raw(
        as.numeric(reg_final_fit$Point.est),
        y
      )
      reg_pred_int_raw <- .numeric_interval(reg_final_fit$pred.int)
    } else {
      # Multivariate final fit
      if (is.character(n.best) && n.best == "all") {
        # Use NNS.reg with n.best = "all"
        reg_final_fit <- suppressWarnings(
          NNS.reg(
            train_design,
            train_y_fit,
            point.est = test_design,
            plot = FALSE,
            residual.plot = FALSE,
            n.best = "all",
            order = order,
            type = "REG",
            factor.2.dummy = FALSE,
            dist = dist,
            ncores = ncores,
            point.only = TRUE,
            confidence.interval = pred.int
          )
        )
        reg_raw_final <- .sanitize_raw(
          as.numeric(reg_final_fit$Point.est),
          y
        )
        reg_pred_int_raw <- .numeric_interval(reg_final_fit$pred.int)
        # Report the full RPM row count; the final fit already holds the RPM.
        reg_best_k <- if (!is.null(reg_final_fit$RPM)) nrow(reg_final_fit$RPM) else nrow(train_design)
      } else {
        # numeric n.best
        reg_final_fit <- suppressWarnings(
          NNS.reg(
            train_design,
            train_y_fit,
            point.est = test_design,
            plot = FALSE,
            residual.plot = FALSE,
            n.best = n.best,
            order = order,
            type = "REG",
            factor.2.dummy = FALSE,
            dist = dist,
            ncores = ncores,
            point.only = TRUE,
            confidence.interval = pred.int
          )
        )
        reg_raw_final <- .sanitize_raw(
          as.numeric(reg_final_fit$Point.est),
          y
        )
        reg_pred_int_raw <- .numeric_interval(reg_final_fit$pred.int)
      }
    }
  }
  
  # Component predictions retain their own OOF-optimized thresholds. The stack
  # uses the threshold optimized directly on the OOF weighted ensemble.
  if (is_class) {
    reg_output <- if (!is.null(reg_raw_final)) {
      .decode_codes(.round_codes(reg_raw_final, reg_component_threshold))
    } else {
      NA
    }
    dim_output <- if (!is.null(dim_raw_final)) {
      .decode_codes(.round_codes(dim_raw_final, dim_component_threshold))
    } else {
      NA
    }
  } else {
    reg_output <- if (!is.null(reg_raw_final)) reg_raw_final else NA_real_
    dim_output <- if (!is.null(dim_raw_final)) dim_raw_final else NA_real_
  }
  
  if (identical(method, 1L)) {
    stacked_raw <- reg_raw_final
  } else if (identical(method, 2L)) {
    stacked_raw <- dim_raw_final
  } else {
    reg_bad <- !is.finite(reg_raw_final)
    dim_bad <- !is.finite(dim_raw_final)
    if (any(reg_bad & dim_bad)) {
      stop("Both final component models failed for at least one test observation.",
           call. = FALSE)
    }
    reg_use <- reg_raw_final
    dim_use <- dim_raw_final
    reg_use[reg_bad] <- dim_use[reg_bad]
    dim_use[dim_bad] <- reg_use[dim_bad]
    stacked_raw <- component_weights["reg"] * reg_use +
      component_weights["dim.red"] * dim_use
  }
  
  stacked_output <- if (is_class) {
    .decode_codes(.round_codes(stacked_raw, probability.threshold))
  } else {
    stacked_raw
  }
  
  reg_pred_int <- if (is_class) {
    .decode_interval(reg_pred_int_raw, reg_component_threshold)
  } else {
    reg_pred_int_raw
  }
  dim_pred_int <- if (is_class) {
    .decode_interval(dim_pred_int_raw, dim_component_threshold)
  } else {
    dim_pred_int_raw
  }
  
  if (is.null(pred.int)) {
    stacked_pred_int_raw <- NULL
  } else if (identical(method, 1L)) {
    stacked_pred_int_raw <- reg_pred_int_raw
  } else if (identical(method, 2L)) {
    stacked_pred_int_raw <- dim_pred_int_raw
  } else if (is.null(reg_pred_int_raw)) {
    stacked_pred_int_raw <- dim_pred_int_raw
  } else if (is.null(dim_pred_int_raw)) {
    stacked_pred_int_raw <- reg_pred_int_raw
  } else {
    reg_pi <- as.data.frame(reg_pred_int_raw, check.names = FALSE)
    dim_pi <- as.data.frame(dim_pred_int_raw, check.names = FALSE)
    if (!identical(dim(reg_pi), dim(dim_pi))) {
      stop("Component prediction intervals have incompatible dimensions.",
           call. = FALSE)
    }
    stacked_pred_int_raw <- as.data.frame(
      component_weights["reg"] * as.matrix(reg_pi) +
        component_weights["dim.red"] * as.matrix(dim_pi),
      check.names = FALSE
    )
    names(stacked_pred_int_raw) <- names(reg_pi)
  }
  
  stacked_pred_int <- if (is_class) {
    .decode_interval(stacked_pred_int_raw, probability.threshold)
  } else {
    stacked_pred_int_raw
  }
  
  result <- list(
    OBJfn.reg = unname(as.numeric(reg_best_score)),
    NNS.reg.n.best = unname(as.integer(reg_best_k)),
    probability.threshold = unname(as.numeric(probability.threshold)),
    OBJfn.dim.red = unname(as.numeric(dim_best_score)),
    NNS.dim.red.threshold = unname(as.numeric(dim_threshold_report)),
    NNS.dim.red.variables = dim_active_variables,
    NNS.dim.red.coefficients = dim_coefficients_report,
    reg = reg_output,
    reg.pred.int = .NNS.df(reg_pred_int),
    dim.red = dim_output,
    dim.red.pred.int = .NNS.df(dim_pred_int),
    stack = stacked_output,
    pred.int = .NNS.df(stacked_pred_int),
    weights = component_weights,
    class.levels = if (is_class) class_values else NULL
  )
  
  .NNS.out(result)
}
