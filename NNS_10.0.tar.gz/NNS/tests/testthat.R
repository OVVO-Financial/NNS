library(testthat)
library(NNS)

test_check("NNS")
