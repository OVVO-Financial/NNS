#' Lower Partial Moment
#'
#' This function generates a univariate lower partial moment for any degree or target.
#'
#' @param degree numeric; \code{(degree = 0)} is frequency, \code{(degree = 1)} is area. At \code{degree = 0} an observation equal to the target is counted (\code{variable <= target}).
#' @param target numeric; Set to \code{target = mean(variable)} for classical equivalences, but does not have to be.
#'   When \code{excess_ret = FALSE}, this can be a scalar or a vectorized target for the standard partial moment calculation.
#'   When \code{excess_ret = TRUE}, it is interpreted element-wise as the benchmark/threshold relative to \code{variable}.
#' @param variable a numeric vector. \link{data.frame} or \link{list} type objects are not permissible.
#' @param excess_ret logical; \code{FALSE} (default). If \code{TRUE}, switches from the standard vectorized-target
#'   partial moment to an element-wise excess-deviation calculation. For \code{LPM}, this computes
#'   \code{pmax(target - variable, 0)} raised to \code{degree} and averaged. In this mode, \code{target}
#'   must have length 1 or the same length as \code{variable}.
#' @return LPM of variable
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. and Nawrocki, D. (2013) "Nonlinear Nonparametric Statistics: Using Partial Moments" (ISBN: 1490523995, 2nd edition: \url{https://ovvo-financial.github.io/NNS/book/})
#' @examples
#' set.seed(123)
#' x <- rnorm(100)
#' LPM(0, mean(x), x)
#' @export

LPM <- function(degree, target, variable, excess_ret = FALSE) {
  target <- .nns_target(target)
  variable <- .nns_sample(variable, "variable", na = "reject", inf = "reject")
  .nns_finite(target, "target")
  degree <- .nns_degree(degree)

  if (!excess_ret && length(target) > 1) {
    return(LPM_CPv(degree, target, variable))
  }
  
  LPM_RCPP(degree, target, variable, excess_ret)
  
}


#' Upper Partial Moment
#'
#' This function generates a univariate upper partial moment for any degree or target.
#'
#' @param degree numeric; \code{(degree = 0)} is frequency, \code{(degree = 1)} is area. At \code{degree = 0} an observation equal to the target is not counted (\code{variable > target}).
#' @param target numeric; Set to \code{target = mean(variable)} for classical equivalences, but does not have to be.
#'   When \code{excess_ret = FALSE}, this can be a scalar or a vectorized target for the standard partial moment calculation.
#'   When \code{excess_ret = TRUE}, it is interpreted element-wise as the benchmark/threshold relative to \code{variable}.
#' @param variable a numeric vector. \link{data.frame} or \link{list} type objects are not permissible.
#' @param excess_ret logical; \code{FALSE} (default). If \code{TRUE}, switches from the standard vectorized-target
#'   partial moment to an element-wise excess-deviation calculation. For \code{UPM}, this computes
#'   \code{pmax(variable - target, 0)} raised to \code{degree} and averaged. In this mode, \code{target}
#'   must have length 1 or the same length as \code{variable}.
#' @return UPM of variable
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. and Nawrocki, D. (2013) "Nonlinear Nonparametric Statistics: Using Partial Moments" (ISBN: 1490523995, 2nd edition: \url{https://ovvo-financial.github.io/NNS/book/})
#' @examples
#' set.seed(123)
#' x <- rnorm(100)
#' UPM(0, mean(x), x)
#' @export

UPM <- function(degree, target, variable, excess_ret = FALSE) {
  target <- .nns_target(target)
  variable <- .nns_sample(variable, "variable", na = "reject", inf = "reject")
  .nns_finite(target, "target")
  degree <- .nns_degree(degree)

  if (!excess_ret && length(target) > 1) {
    return(UPM_CPv(degree, target, variable))
  }
  
  UPM_RCPP(degree, target, variable, excess_ret)
  
}


#' Co‑Lower Partial Moment nD
#'
#' This function generates an n‑dimensional co‑lower partial moment (n >= 2) for any degree or target.
#'
#' @param data   A numeric matrix with observations in rows and variables in columns.
#' @param target A numeric vector, length equal to ncol(data).
#' @param degree numeric; degree for lower deviations (0 = frequency, 1 = area).
#' @param norm   logical; if \code{TRUE} (default) divide by the sum of the co-lower, co-upper and divergent nD partial moments at the same degree and target (→ [0,1]), otherwise return the raw moment. If that sum is 0, as when the target sits on a constant column, the degree-0 value is returned. \code{norm} is ignored at \code{degree = 0}.
#' @return Numeric; the n‑dimensional co‑lower partial moment.
#' @examples
#' \dontrun{
#' mat <- matrix(rnorm(200), ncol = 4)
#' Co.LPM_nD(mat, rep(0, ncol(mat)), degree = 1, norm = FALSE)
#' }
#' @export
Co.LPM_nD <- function(data, target, degree = 0.0, norm = TRUE) {
  data <- .nns_sample_matrix(data, "data", finite = TRUE)
  target <- .nns_thresholds(target)
  degree <- .nns_degree(degree, form = "coerce")
  norm <- as.logical(norm)

  CoLPM_nD_RCPP(data, target, degree, norm)
}


#' Batched Co-Lower Partial Moment nD
#'
#' Internal batched backend for evaluating \code{Co.LPM_nD} over many targets.
#'
#' @param data A numeric matrix with observations in rows and variables in columns.
#' @param targets A numeric matrix with target rows and the same number of columns as data.
#' @param degree numeric; degree for lower deviations.
#' @param norm logical; normalize result.
#' @param strict logical; count only rows strictly below the target in the degree-0 share.
#' @return Numeric vector, one value per row of targets.
#' @keywords internal

Co.LPM_nD.batch <- function(data, targets, degree = 0.0, norm = TRUE, strict = FALSE) {
  data <- .nns_sample_matrix(data, "data", finite = TRUE)
  targets <- .nns_sample_matrix(targets, "targets", finite = TRUE)
  degree <- .nns_degree(degree, form = "coerce")
  norm <- as.logical(norm)
  strict <- as.logical(strict)

  CoLPM_nD_batch_RCPP(data, targets, degree, norm, strict)
}


#' Co‑Upper Partial Moment nD
#'
#' This function generates an n‑dimensional co‑upper partial moment (n >= 2) for any degree or target.
#'
#' @param data   A numeric matrix with observations in rows and variables in columns.
#' @param target A numeric vector, length equal to ncol(data).
#' @param degree numeric; degree for upper deviations (0 = frequency, 1 = area).
#' @param norm   logical; if \code{TRUE} (default) divide by the sum of the co-lower, co-upper and divergent nD partial moments at the same degree and target (→ [0,1]), otherwise return the raw moment. If that sum is 0, as when the target sits on a constant column, the degree-0 value is returned. \code{norm} is ignored at \code{degree = 0}.
#' @return Numeric; the n‑dimensional co‑upper partial moment.
#' @examples
#' \dontrun{
#' mat <- matrix(rnorm(200), ncol = 4)
#' Co.UPM_nD(mat, rep(0, ncol(mat)), degree = 1, norm = FALSE)
#' }
#' @export
Co.UPM_nD <- function(data, target, degree = 0.0, norm = TRUE) {
  data <- .nns_sample_matrix(data, "data", finite = TRUE)
  target <- .nns_thresholds(target)
  degree <- .nns_degree(degree, form = "coerce")
  norm <- as.logical(norm)

  CoUPM_nD_RCPP(data, target, degree, norm)
}


#' Divergent Partial Moment nD
#'
#' This function generates the aggregate n‑dimensional divergent partial moment (n >= 2) for any degree or target.
#'
#' @param data   A numeric matrix with observations in rows and variables in columns.
#' @param target A numeric vector, length equal to ncol(data).
#' @param degree numeric; degree for lower and upper deviations (0 = frequency, 1 = area).
#' @param norm   logical; if \code{TRUE} (default) divide by the sum of the co-lower, co-upper and divergent nD partial moments at the same degree and target (→ [0,1]), otherwise return the raw moment. If that sum is 0, as when the target sits on a constant column, the degree-0 value is returned. \code{norm} is ignored at \code{degree = 0}.
#' @return Numeric; the n-dimensional divergent partial moment.
#' @examples
#' \dontrun{
#' mat <- matrix(rnorm(200), ncol = 4)
#' DPM_nD(mat, rep(0, ncol(mat)), degree = 1, norm = FALSE)
#' }
#' @export
DPM_nD <- function(data, target, degree = 0.0, norm = TRUE) {
  data <- .nns_sample_matrix(data, "data", finite = TRUE)
  target <- .nns_thresholds(target)
  degree <- .nns_degree(degree, form = "coerce")
  norm <- as.logical(norm)

  DPM_nD_RCPP(data, target, degree, norm)
}



#' NNS CDF
#'
#' This function generates an empirical CDF using partial moment ratios \link{LPM.ratio}, and resulting survival, hazard and cumulative hazard functions.
#'
#' @param variable a numeric vector or data.frame of >= 2 variables for joint CDF.
#' @param degree numeric; \code{(degree = 0)} (default) is frequency, the empirical distribution of \code{variable}; \code{(degree = 1)} is area, the share of deviation area below each point, which is not \eqn{P(X \le t)}.
#' @param target numeric; \code{NULL} (default) Must lie within support of each variable (one value per column for multivariate \code{variable}).
#' @param type options("CDF", "survival", "hazard", "cumulative hazard"); \code{"CDF"} (default) Selects type of function to return.  For multivariate \code{variable} the joint survival is \eqn{P(X_1 > t_1, \ldots, X_d > t_d)} at \code{degree = 0}, by inclusion-exclusion over the column subsets for \eqn{d \le 3} and as the share of observations above \eqn{t} in every column for larger \eqn{d}, and the joint upper partial moment \link{Co.UPM_nD} at \code{degree > 0}, normalised like the CDF.  The multivariate cumulative hazard is the transform \eqn{-\log S(t)} and requires \code{degree = 0}; it is not automatically an integral of a scalar multivariate hazard. Multivariate \code{type = "hazard"} is unsupported and raises an error: a joint density-over-survival or a coordinate-hazard definition requires a separate estimator, and dividing the joint CDF by survival does not estimate either.  At \code{degree > 0} with two or more columns, each target's co-partial moment is normalised by its own total (a zero total, from a constant column at its target, gives the degree-0 value), so the "CDF" and "survival" values are generalised co-partial-moment ratios, not a joint distribution function: they can assign a negative probability to a rectangle.  At \code{degree = 0}, and in one dimension at any degree, they are proper distribution functions; at positive degree the univariate induced law describes deviation-area balance rather than the frequency law of the original variable.
#' @param plot logical; plots CDF.
#' @return Returns:
#' \itemize{
#'  \item{\code{"Function"}} a data.frame (class \code{NNS.data.frame}) containing the observations and the resulting function of the variable.
#'  \item{\code{"target.value"}} value of the function at the \code{target} argument.
#' }
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. and Nawrocki, D. (2013) "Nonlinear Nonparametric Statistics: Using Partial Moments" (ISBN: 1490523995, 2nd edition: \url{https://ovvo-financial.github.io/NNS/book/})
#'
#' Viole, F. (2017) "Continuous CDFs and ANOVA with NNS"  \doi{10.2139/ssrn.3007373}
#' 
#' @examples
#' \dontrun{
#' set.seed(123)
#' x <- rnorm(100)
#' NNS.CDF(x)
#'
#' ## Empirical CDF (degree = 0)
#' NNS.CDF(x)
#'
#' ## Area-weighted CDF (degree = 1): the share of deviation area below each point
#' NNS.CDF(x, 1)
#'
#' ## Joint CDF
#' x <- rnorm(5000) ; y <- rnorm(5000)
#' A <- cbind(x,y)
#'
#' NNS.CDF(A, 0)
#'
#' ## Joint CDF with target
#' NNS.CDF(A, 0, target = rep(0, ncol(A)))
#' }
#' @export


NNS.CDF <- function(variable,
                    degree = 0,
                    target = NULL,
                    type   = "CDF",
                    plot   = TRUE) {
  
  if (is.data.frame(variable) && ncol(variable) > 1L) variable <- .nns_measure_frame(variable)
  variable <- .nns_observed(.nns_measure_column(variable), rows = TRUE)

  # — Bounds check
  if (!is.null(target)) {
    .nns_no_factor(target, "target")
    if (is.null(dim(variable))||ncol(variable)==1) {
      if (target<min(variable)||target>max(variable)) stop("target out of bounds")
    } else {
      if (length(target) != ncol(variable)) stop("target must have one value per column of variable")
      lo <- apply(variable, 2, min); hi <- apply(variable, 2, max)
      if (any(target < lo | target > hi)) stop("target out of bounds")
    }
  }
  
  # — Validate type
  type <- tolower(type)
  if (!type%in%c("cdf","survival","hazard","cumulative hazard")) stop("invalid type")
  
  # — Axis labels
  mc <- match.call(); vc <- mc$variable
  if (is.null(dim(variable))||ncol(variable)==1) {
    vn <- deparse(vc)
  } else if (!is.null(colnames(variable))) {
    xlab <- colnames(variable)[1]; ylab <- colnames(variable)[2]
  } else {
    expr <- deparse(vc); xlab <- paste0(expr,"[,1]"); ylab <- paste0(expr,"[,2]")
  }
  
  # — Univariate branch
  if (is.null(dim(variable))||ncol(variable)==1) {
    x    <- sort(variable)
    degree <- .nns_degree(degree)
    sample <- .nns_native_sample(variable, "variable")
    pval <- LPM_ratio_RCPP(degree, .nns_target(x, native = TRUE), sample)
    DT   <- data.frame(x, pval)
    colname <- switch(type,
                      cdf="CDF",
                      survival="S(x)",
                      hazard="h(x)",
                      `cumulative hazard`="H(x)")
    names(DT) <- c("x",colname)
    
    # adjust pval for survival/hazard/cumhaz
    if (type=="survival") DT[[2]] <- 1-DT[[2]]
    if (type=="hazard") {
      n <- length(x); w <- min(10,n-1)
      F <- pval
      if (x[1] == x[n]) stop("type = 'hazard' requires at least two distinct values of variable")
      proxy <- vapply(seq_along(x),function(i){
        lo<-max(1,i-w%/%2);hi<-min(n,i+w%/%2)
        # A window lying inside a run of tied values has zero width (0/0):
        # widen it to the neighbouring distinct values (x is sorted).
        if (x[hi] == x[lo]) {
          lo <- max(1L, findInterval(x[i], x, left.open = TRUE))
          hi <- min(n, findInterval(x[i], x) + 1L)
        }
        (F[hi]-F[lo])/(x[hi]-x[lo])},numeric(1))
      fit <- NNS.reg(x, pmax(proxy,1e-10), type="REG", order=NULL, n.best=1, point.est=target, plot=FALSE)
      DT[[2]] <- pmin(pmax(fit$Fitted$y.hat / pmax(1-F,1e-10),0),1e6)
    }
    if (type=="cumulative hazard") DT[[2]] <- pmax(-log(pmax(1-pval,1e-10)),0)
    
    # compute target.value
    if (is.null(target)) {
      Pv <- numeric(0)
    } else {
      Pv <- LPM_ratio_RCPP(degree, .nns_target(target, native = TRUE), sample)
      if (type=="survival") Pv <- 1-Pv
      # The same transformation of the survival at target as the curve uses at each x.
      if (type=="hazard") Pv <- pmin(pmax(fit$Point.est / pmax(1-Pv,1e-10),0),1e6)
      if (type=="cumulative hazard") Pv <- pmax(-log(pmax(1-Pv,1e-10)),0)
    }
    
    # plotting
    if (plot) {
      plot(DT$x,DT[[2]],type="s",lwd=2,pch=19,col="steelblue",xlab=vn,ylab=colname,main=toupper(type))
      points(DT$x,DT[[2]],pch=19,col="steelblue")
      if(length(Pv)){
        segments(target,0,target,Pv,col="red",lty=2,lwd=2)
        segments(min(x),Pv,target,Pv,col="red",lty=2,lwd=2)
        points(target,Pv,pch=19,col="green")
      }
    }
    
    return(list(Function=.NNS.df(DT),target.value=Pv))
  }
  
  # — Multivariate case (d >= 2)
  if (!is.null(dim(variable)) && ncol(variable) >= 2) {
    if (type == "hazard")
      stop("Multivariate type = 'hazard' is not implemented: a joint density or coordinate-hazard definition is required. Use 'survival' or 'cumulative hazard' for the documented joint survival transforms.")
    # At degree > 0 each target's co-partial moment is normalised by its own
    # total, which is not a joint distribution function (#100): the
    # cumulative-hazard interpretation therefore requires degree 0.
    if (degree > 0 && type == "cumulative hazard")
      stop("type = '", type, "' needs degree = 0 for multivariate variable: at degree > 0 the joint ratio is not a distribution function.")
    xlab <- colnames(variable)[1]
    ylab <- if(ncol(variable) >= 2) colnames(variable)[2] else ""
    
    # Compute joint conditional CDF using one batched C++ call.
    # This replaces n R-level Co.LPM_nD dispatches and n parallel launches.
    variable <- .nns_sample_matrix(variable, "data", finite = TRUE)
    degree <- .nns_degree(degree, form = "coerce")
    if (!is.null(target)) target <- .nns_thresholds(target)
    d <- ncol(variable)
    CDF <- CoLPM_nD_batch_RCPP(variable, variable, degree, TRUE)
    
    # Joint survival S(t) = P(X_1 > t_1, ..., X_d > t_d). At degree 0 use
    # inclusion-exclusion, S = sum_A (-1)^|A| F_A(t_A) over subsets A of the
    # coordinates, up to d = 3; beyond that its 2^d terms are slow and cancel,
    # so count the rows above t directly.
    # For degree > 0 use Co.UPM_nD(X, t) = Co.LPM_nD(-X, -t); strict keeps ties
    # out of the degree-0 share used at a zero total, as Co.UPM_nD does.
    joint.survival <- function(points, joint_cdf) {
      points <- matrix(points, ncol = d)
      if (degree > 0) return(CoLPM_nD_batch_RCPP(-variable, -points, degree, TRUE, strict = TRUE))
      if (d > 3) {
        cols <- lapply(seq_len(d), function(j) variable[, j])
        o1 <- order(cols[[1]]); v1 <- cols[[1]][o1]; nv <- length(v1)
        above <- function(p) {
          k <- findInterval(p[1], v1)
          if (k >= nv) return(0L)
          rows <- o1[(k + 1L):nv]
          for (j in 2:d) if (length(rows)) rows <- rows[cols[[j]][rows] > p[j]]
          length(rows)
        }
        return(apply(points, 1, above) / nrow(variable))
      }
      marginals <- vapply(seq_len(d), function(j) LPM.ratio(degree, points[, j], variable[, j]),
                          numeric(nrow(points)))
      S <- 1 - rowSums(matrix(marginals, ncol = d))
      if (d == 3) {
        for (A in utils::combn(d, 2, simplify = FALSE)) {
          S <- S + CoLPM_nD_batch_RCPP(variable[, A, drop = FALSE], points[, A, drop = FALSE],
                                      degree, TRUE)
        }
      }
      S + (-1)^d * joint_cdf
    }
    
    if (type != "cdf") S <- joint.survival(variable, CDF)
    
    # Apply transformation based on type
    if (type == "survival") {
      CDF <- pmax(0, pmin(1, S))
    }
    
    if (type == "cumulative hazard") {
      CDF <- pmax(-log(pmax(S, 1e-10)), 0)
    }
    
    # Target evaluation (the same function as the rows, evaluated at target)
    Pv <- numeric(0)
    if (!is.null(target)) {
      Pv <- CoLPM_nD_RCPP(variable, target, degree, TRUE)
      if (type != "cdf") S_t <- joint.survival(target, Pv)
      if (type == "survival") {
        Pv <- max(0, min(1, S_t))
      }
      if (type == "cumulative hazard") {
        Pv <- pmax(-log(pmax(S_t, 1e-10)), 0)
      }
    }
    
    if (plot && ncol(variable) == 2) {
      .nns_require_rgl()
      x1 <- variable[, 1]; x2 <- variable[, 2]
      u1 <- LPM.ratio(degree, x1, x1)
      u2 <- LPM.ratio(degree, x2, x2)

      rgl::plot3d(u1, u2, CDF,
                  xlab = paste0(xlab, " uniform"), ylab = paste0(ylab, " uniform"), zlab = toupper(type),
                  col  = "steelblue", pch = 19, box = FALSE)
      
      if (length(Pv)) {
        ut1 <- LPM.ratio(degree, target[1], x1)
        ut2 <- LPM.ratio(degree, target[2], x2)
        
        # Target point (green)
        rgl::points3d(ut1, ut2, Pv, col = "green", pch = 19)
        
        # Horizontal segment along x at level Pv
        rgl::segments3d(
          x = c(min(u1), ut1),
          y = c(ut2,     ut2),
          z = c(Pv,      Pv),
          col = "red", lwd = 2, lty = "dashed"
        )
        rgl::text3d(ut1,min(u2), Pv, 
                    text = paste0("x = ", round(target[1], 3)), 
                    col = "red", pos = 2, cex = 0.9)
        
        # Horizontal segment along y at level Pv
        rgl::segments3d(
          x = c(ut1,     ut1),
          y = c(min(u2), ut2),
          z = c(Pv,      Pv),
          col = "red", lwd = 2, lty = "dashed"
        )
        rgl::text3d(min(u1), ut2, Pv, 
                    text = paste0("y = ", round(target[2], 3)), 
                    col = "red", pos = 2, cex = 0.9)
        
        # Final segment to CDF axis (min u1, min u2, Pv)
        rgl::segments3d(
          x = c(ut1,      max(u1)),
          y = c(ut2,      max(u2)),
          z = c(Pv,       Pv),
          col = "red", lwd = 2, lty = "dashed"
        )
        rgl::text3d(max(u1), max(u2), Pv,
                    text = paste0("CDF = ", round(Pv, 4)),
                    col = "red", pos = 2, cex = 0.9)
      }
    }
    
    outDT <- data.frame(variable, CDF = CDF, check.names = FALSE)
    return(list(Function = .NNS.df(outDT), target.value = Pv))
  }
}




#' NNS moments
#'
#' This function returns the first 4 moments of the distribution.
#'
#' @param x a numeric vector.
#' @param population logical; \code{TRUE} (default) returns the population (unadjusted) statistics. \code{FALSE} returns the sample-adjusted statistics (variance with \code{n - 1}, sample skewness and sample excess kurtosis).
#' @return Returns:
#' \itemize{
#'  \item{\code{"$mean"}} mean of the distribution.
#'  \item{\code{"$variance"}} variance of the distribution.
#'  \item{\code{"$skewness"}} skewness of the distribution.
#'  \item{\code{"$kurtosis"}} excess kurtosis.
#' }
#' @author Fred Viole, OVVO Financial Systems
#' @references Viole, F. and Nawrocki, D. (2013) "Nonlinear Nonparametric Statistics: Using Partial Moments" (ISBN: 1490523995, 2nd edition: \url{https://ovvo-financial.github.io/NNS/book/})
#'
#' @examples
#' \dontrun{
#' set.seed(123)
#' x <- rnorm(100)
#' NNS.moments(x)
#' }
#' @export

NNS.moments <- function(x, population = TRUE) {
  x <- .nns_sample(x, "x", na = "reject", inf = "reject")
  
  n <- length(x)
  m <- mean(x)
  z <- x - m
  # The mean can round onto an observation when the spread is small.
  if (all(is.finite(z))) z <- z - mean(z)
  
  variance <- mean(z^2)
  skew_base <- mean(z^3)
  kurt_base <- mean(z^4)
  
  if (population) {
    skewness <- skew_base / variance^(3 / 2)
    kurtosis <- (kurt_base / variance^2) - 3
  } else {
    # Adjusted Fisher-Pearson G1: n/((n-1)(n-2)) * sum(z^3) / s^3, with s the
    # sample (n-1) standard deviation, as in the kurtosis branch below.
    skewness <- if (n < 3L) NaN else (n / ((n - 1) * (n - 2))) *
      ((n * skew_base) / (variance * (n / (n - 1)))^(3 / 2))
    
    kurtosis <- ((n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3))) *
      ((n * kurt_base) / (variance * (n / (n - 1)))^2) -
      ((3 * ((n - 1)^2)) / ((n - 2) * (n - 3)))
    
    variance <- variance * (n / (n - 1))
  }
  
  return(list(
    mean = m,
    variance = variance,
    skewness = skewness,
    kurtosis = kurtosis
  ))
}




#' Partial Moment Matrix
#' @name PM.matrix
#' @title Partial Moment Matrix
#' @description Builds a list containing CUPM, DUPM, DLPM, CLPM and the overall covariance matrix.
#' @param LPM_degree numeric; lower partial moment degree (0 = freq, 1 = area).
#' @param UPM_degree numeric; upper partial moment degree (0 = freq, 1 = area).
#' @param target numeric vector; thresholds for each column. There is no default: pass \code{NULL} to use the sample mean of each column.
#' @param variable numeric matrix or data.frame.
#' @param pop_adj logical; \code{TRUE} applies the sample adjustment \code{n / (n - 1)} to the co-/divergent moments (with both degrees 1, \code{target = NULL} and \code{norm = FALSE}, the covariance matrix then equals \code{cov()}). It is ignored when either degree is 0.
#' @param norm logical; default FALSE. If TRUE, each quadrant matrix is cell-wise normalized so their sum is 1 at each (i,j). A cell whose four moments are all 0, as when a column is constant at its target, takes the degree-0 values.  
#' @return A list: $cupm, $dupm, $dlpm, $clpm, $cov.matrix.
#' @note When \code{norm = TRUE}, each cell (i,j) of the four quadrant matrices
#' is normalized so that their sum equals 1.  In this case, 
#' \code{$cov.matrix} is computed as 
#' \code{$cupm + $clpm - $dupm - $dlpm}, yielding a dimensionless,
#' signed dependence measure bounded between -1 and 1.
#' This representation discards magnitude information and is therefore
#' a lossy nonlinear correlation matrix.  A higher fidelity nonlinear
#' correlation matrix is available via the \code{NNS.dep} function.
#' @examples
#' set.seed(123)
#' A <- cbind(rnorm(100), rnorm(100), rnorm(100))
#' 
#' # Uses norm = FALSE by default
#' PM.matrix(1, 1, target = NULL, variable = A, pop_adj = TRUE)
#' 
#' # Enable normalization
#' PM.matrix(1, 1, target = NULL, variable = A, pop_adj = TRUE, norm = TRUE)
#' 
#' # Use 0's for targets
#' PM.matrix(1, 1, target = rep(0, ncol(A)), variable = A, pop_adj = TRUE)        
#' 
#' # Use variable medians as targets
#' PM.matrix(1, 1, target = apply(A, 2, "median"), variable = A, pop_adj = TRUE)  
#' @export
PM.matrix <- function(LPM_degree, UPM_degree, target, variable, pop_adj, norm = FALSE) {
  LPM_degree <- .nns_degree(LPM_degree, "LPM_degree")
  UPM_degree <- .nns_degree(UPM_degree, "UPM_degree")
  if (is.null(variable)) stop("variable can't be null")
  variable <- .nns_sample_matrix(variable, "variable")
  target <- .nns_target(target, native = TRUE, means = TRUE)
  PMMatrix_RCPP(LPM_degree, UPM_degree, target, variable, pop_adj, norm)
}

#' @name Co.LPM
#' @title Co‑Lower Partial Moment
#' @description
#'   Computes the co‑lower partial moment (lower‑left quadrant 4) between two
#'   equal‑length numeric vectors at any degree and target.
#' @param degree_lpm numeric; degree for x ("degree_x"). degree = 0 gives frequency, degree = 1 gives area. At degree 0 an observation equal to its target is counted (\code{x <= target_x}, \code{y <= target_y}).
#' @param x numeric vector of observations.
#' @param y numeric vector of the same length as x.
#' @param target_x numeric vector; thresholds for x. There is no default: pass \code{NULL} to use \code{mean(x)}.
#' @param target_y numeric vector; thresholds for y. There is no default: pass \code{NULL} to use \code{mean(y)}. \code{target_x} and \code{target_y} must be non-empty and the same length, or one of them length 1.
#' @param degree_y numeric; optional degree for y. If omitted, `degree_lpm` is
#'   used for both x and y.
#' @return Numeric vector of co‑LPM values.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100); y <- rnorm(100)
#'   Co.LPM(0, x, y, mean(x), mean(y))
#' @export
Co.LPM <- function(degree_lpm, x, y, target_x, target_y, degree_y = NULL) {
  if (is.null(degree_y)) degree_y <- degree_lpm
  degree_lpm <- .nns_degree(degree_lpm, "degree_lpm")
  pair <- .nns_moment_pair(x, y)
  target_x <- .nns_target(target_x, native = TRUE)
  target_y <- .nns_target(target_y, native = TRUE)
  degree_y <- .nns_degree(degree_y, "degree_y")
  CoLPM_RCPP(degree_lpm, pair$x, pair$y, target_x, target_y, degree_y)
}


#' @name Co.UPM
#' @title Co‑Upper Partial Moment
#' @description
#'   Computes the co‑upper partial moment (upper‑right quadrant 1) between two
#'   equal‑length numeric vectors at any degree and target.
#' @param degree_upm numeric; degree for x ("degree_x"). degree = 0 gives frequency, degree = 1 gives area. At degree 0 an observation equal to its target is not counted (\code{x > target_x}, \code{y > target_y}).
#' @param x numeric vector of observations.
#' @param y numeric vector of the same length as x.
#' @param target_x numeric vector; thresholds for x. There is no default: pass \code{NULL} to use \code{mean(x)}.
#' @param target_y numeric vector; thresholds for y. There is no default: pass \code{NULL} to use \code{mean(y)}. \code{target_x} and \code{target_y} must be non-empty and the same length, or one of them length 1.
#' @param degree_y numeric; optional degree for y. If omitted, `degree_upm` is
#'   used for both x and y.
#' @return Numeric vector of co‑UPM values.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100); y <- rnorm(100)
#'   Co.UPM(0, x, y, mean(x), mean(y))
#' @export
Co.UPM <- function(degree_upm, x, y, target_x, target_y, degree_y = NULL) {
  if (is.null(degree_y)) degree_y <- degree_upm
  degree_upm <- .nns_degree(degree_upm, "degree_upm")
  pair <- .nns_moment_pair(x, y)
  target_x <- .nns_target(target_x, native = TRUE)
  target_y <- .nns_target(target_y, native = TRUE)
  degree_y <- .nns_degree(degree_y, "degree_y")
  CoUPM_RCPP(degree_upm, pair$x, pair$y, target_x, target_y, degree_y)
}

#' @name LPM.ratio
#' @title Lower Partial Moment Ratio
#' @description
#'   This function generates a standardized univariate lower partial moment
#'   of any non‑negative degree for a given target.
#' @param degree numeric; degree = 0 gives frequency (CDF), degree = 1 gives area. At degree 0 an observation equal to the target is counted (\code{variable <= target}).
#' @param target numeric vector; threshold(s). There is no default: pass \code{NULL} to use \code{mean(variable)}.
#' @param variable numeric vector or data‑frame column to evaluate.
#' @return Numeric vector of standardized lower partial moments. For
#'   \code{degree > 0}, a target at which every observation equals the target
#'   (0/0) returns the \code{degree = 0} ratio.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @references
#'   Viole, F. (2017) Continuous CDFs and ANOVA with NNS. \doi{10.2139/ssrn.3007373}
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100)
#'   LPM.ratio(0, mean(x), x)
#' \dontrun{
#'   plot(sort(x), LPM.ratio(0, sort(x), x))
#'   plot(sort(x), LPM.ratio(1, sort(x), x))
#' }
#' @export
LPM.ratio <- function(degree, target, variable) {
  degree <- .nns_degree(degree)
  force(target)
  variable <- .nns_native_sample(variable, "variable")
  target <- .nns_target(target, native = TRUE)
  LPM_ratio_RCPP(degree, target, variable)
}


#' @name UPM.ratio
#' @title Upper Partial Moment Ratio
#' @description
#'   This function generates a standardized univariate upper partial moment
#'   of any non‑negative degree for a given target.
#' @param degree numeric; degree = 0 gives frequency, degree = 1 gives area. At degree 0 an observation equal to the target is not counted (\code{variable > target}).
#' @param target numeric vector; threshold(s). There is no default: pass \code{NULL} to use \code{mean(variable)}.
#' @param variable numeric vector or data‑frame column to evaluate.
#' @return Numeric vector of standardized upper partial moments. For
#'   \code{degree > 0}, a target at which every observation equals the target
#'   (0/0) returns the \code{degree = 0} ratio.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100)
#'   UPM.ratio(0, mean(x), x)
#' \dontrun{
#'   plot(sort(x), UPM.ratio(0, sort(x), x))
#' }
#' @export
UPM.ratio <- function(degree, target, variable) {
  degree <- .nns_degree(degree)
  force(target)
  variable <- .nns_native_sample(variable, "variable")
  target <- .nns_target(target, native = TRUE)
  UPM_ratio_RCPP(degree, target, variable)
}


#' @name D.LPM
#' @title Divergent‑Lower Partial Moment
#' @description
#'   Computes the divergent lower partial moment (lower‑right quadrant 3)
#'   between two equal‑length numeric vectors. \code{degree_upm} applies to \code{x}
#'   (above \code{target_x}) and \code{degree_lpm} to \code{y} (below \code{target_y}).
#' @param degree_lpm numeric; LPM degree = 0 gives frequency, = 1 gives area.
#' @param degree_upm numeric; UPM degree = 0 gives frequency, = 1 gives area.
#' @param x numeric vector of observations.
#' @param y numeric vector of the same length as x.
#' @param target_x numeric vector; thresholds for x. There is no default: pass \code{NULL} to use \code{mean(x)}.
#' @param target_y numeric vector; thresholds for y. There is no default: pass \code{NULL} to use \code{mean(y)}. \code{target_x} and \code{target_y} must be non-empty and the same length, or one of them length 1.
#' @return Numeric vector of divergent LPM values.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100); y <- rnorm(100)
#'   D.LPM(0, 0, x, y, mean(x), mean(y))
#' @export
D.LPM <- function(degree_lpm, degree_upm, x, y, target_x, target_y) {
  degree_lpm <- .nns_degree(degree_lpm, "degree_lpm")
  degree_upm <- .nns_degree(degree_upm, "degree_upm")
  pair <- .nns_moment_pair(x, y)
  target_x <- .nns_target(target_x, native = TRUE)
  target_y <- .nns_target(target_y, native = TRUE)
  DLPM_RCPP(degree_lpm, degree_upm, pair$x, pair$y, target_x, target_y)
}


#' @name D.UPM
#' @title Divergent‑Upper Partial Moment
#' @description
#'   Computes the divergent upper partial moment (upper‑left quadrant 2)
#'   between two equal‑length numeric vectors. \code{degree_lpm} applies to \code{x}
#'   (below \code{target_x}) and \code{degree_upm} to \code{y} (above \code{target_y}).
#' @param degree_lpm numeric; LPM degree = 0 gives frequency, = 1 gives area.
#' @param degree_upm numeric; UPM degree = 0 gives frequency, = 1 gives area.
#' @param x numeric vector of observations.
#' @param y numeric vector of the same length as x.
#' @param target_x numeric vector; thresholds for x. There is no default: pass \code{NULL} to use \code{mean(x)}.
#' @param target_y numeric vector; thresholds for y. There is no default: pass \code{NULL} to use \code{mean(y)}. \code{target_x} and \code{target_y} must be non-empty and the same length, or one of them length 1.
#' @return Numeric vector of divergent UPM values.
#' @author Fred Viole, OVVO Financial Systems
#' @references
#'   Viole, F. & Nawrocki, D. (2013) *Nonlinear Nonparametric Statistics: Using Partial Moments* (ISBN:1490523995)
#' @examples
#'   set.seed(123)
#'   x <- rnorm(100); y <- rnorm(100)
#'   D.UPM(0, 0, x, y, mean(x), mean(y))
#' @export
D.UPM <- function(degree_lpm, degree_upm, x, y, target_x, target_y) {
  degree_lpm <- .nns_degree(degree_lpm, "degree_lpm")
  degree_upm <- .nns_degree(degree_upm, "degree_upm")
  pair <- .nns_moment_pair(x, y)
  target_x <- .nns_target(target_x, native = TRUE)
  target_y <- .nns_target(target_y, native = TRUE)
  DUPM_RCPP(degree_lpm, degree_upm, pair$x, pair$y, target_x, target_y)
}