// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include "central_tendencies.h"

using namespace Rcpp;

// ---------- helpers ----------

static inline double frac_part(double x) {
  return x - std::floor(x);
}

static inline double mean_vec(const double* v, std::size_t n) {
  if (n == 0) return NA_REAL;
  long double s = 0.0L;
  for (std::size_t i = 0; i < n; ++i) s += v[i];
  return static_cast<double>(s / n);
}

static inline double nearest_int_half_up(double x) {
  double f = std::floor(x);
  return ( (x - f) < 0.5 ) ? f : std::ceil(x);
}

// Given a sorted vector xs, reproduce the q1, q2, q3 *exactly* as in the R code.
// - If length is even: q1 = xs[l*.25], q2 = xs[l*.5], q3 = xs[l*.75]  (1-based indexing)
// - If length is odd : q1 and q3 via linear interpolation at l*p, q2 = average of floor/ceil
static void quartiles_like_R_code(const std::vector<double>& xs, double& q1, double& q2, double& q3) {
  const int l = static_cast<int>(xs.size());
  const double l25 = l * 0.25;
  const double l50 = l * 0.50;
  const double l75 = l * 0.75;
  
  if (l % 2 == 0) {
    // 1-based positions in R -> convert to 0-based for C++
    int i25 = std::max(1, (int)std::floor(l25)) - 1;
    int i50 = std::max(1, (int)std::floor(l50)) - 1;
    int i75 = std::max(1, (int)std::floor(l75)) - 1;
    q1 = xs[i25];
    q2 = xs[i50];
    q3 = xs[i75];
  } else {
    // q1 interpolated
    int f25 = (int)std::floor(l25);
    int c25 = (int)std::ceil(l25);
    f25 = std::max(1, f25); // guard
    c25 = std::max(1, c25);
    f25 = std::min(f25, l);
    c25 = std::min(c25, l);
    double w25 = frac_part(l25);
    q1 = xs[f25 - 1] + w25 * (xs[c25 - 1] - xs[f25 - 1]);
    
    // q2 average of floor and ceil positions
    int f50 = (int)std::floor(l50);
    int c50 = (int)std::ceil(l50);
    f50 = std::max(1, f50);
    c50 = std::max(1, c50);
    f50 = std::min(f50, l);
    c50 = std::min(c50, l);
    q2 = 0.5 * (xs[f50 - 1] + xs[c50 - 1]);
    
    // q3 interpolated
    int f75 = (int)std::floor(l75);
    int c75 = (int)std::ceil(l75);
    f75 = std::max(1, f75);
    c75 = std::max(1, c75);
    f75 = std::min(f75, l);
    c75 = std::min(c75, l);
    double w75 = frac_part(l75);
    q3 = xs[f75 - 1] + w75 * (xs[c75 - 1] - xs[f75 - 1]);
  }
}

// Minimal replacement for NNS_bin used by mode/gravity. Bins are
// [origin + k*width, origin + (k+1)*width), k = 0 .. nbins-1, with
// nbins = floor((max - origin) / width + 1e-12) + 1.
//
// Gravity and mode only read counts within 6 bins of a non-empty bin, so runs
// of more than kMaxEmptyRun empty bins keep only their first and last
// kMaxEmptyRun / 2 bins: results are bit-identical and memory is O(n). A width
// so small that the bin count exceeds 2^52 is widened to (max - origin) / 2^52.
static constexpr std::int64_t kMaxEmptyRun = 16;
static constexpr double kMaxBinIndex = 4503599627370496.0;  // 2^52

static void simple_bin_counts(const double* xs, std::size_t n_xs, double width, double origin,
                              std::vector<double>& bin_names, std::vector<int>& counts) {
  bin_names.clear();
  counts.clear();
  if (n_xs == 0) return;

  const double xmax = xs[n_xs - 1];
  double last = std::floor((xmax - origin) / width + 1e-12);
  if (!(last < kMaxBinIndex)) {
    width = (xmax - origin) / kMaxBinIndex;
    last = std::floor((xmax - origin) / width + 1e-12);
    if (!(last < kMaxBinIndex)) last = kMaxBinIndex;
  }
  const std::int64_t nbins = (last >= 0.0) ? static_cast<std::int64_t>(last) + 1 : 1;
  const std::int64_t cap = static_cast<std::int64_t>(n_xs) * (kMaxEmptyRun + 1) + kMaxEmptyRun;
  bin_names.reserve(static_cast<std::size_t>(std::min(nbins, cap)));
  counts.reserve(static_cast<std::size_t>(std::min(nbins, cap)));

  auto push_bin = [&](std::int64_t k, int c) {
    bin_names.push_back(origin + static_cast<double>(k) * width);
    counts.push_back(c);
  };
  auto push_empty_run = [&](std::int64_t first, std::int64_t last_bin) {
    const std::int64_t len = last_bin - first + 1;
    if (len <= 0) return;
    if (len <= kMaxEmptyRun) {
      for (std::int64_t k = first; k <= last_bin; ++k) push_bin(k, 0);
      return;
    }
    const std::int64_t half = kMaxEmptyRun / 2;
    for (std::int64_t k = first; k < first + half; ++k) push_bin(k, 0);
    for (std::int64_t k = last_bin - half + 1; k <= last_bin; ++k) push_bin(k, 0);
  };

  // xs is sorted, so bin indices are non-decreasing.
  const double top = static_cast<double>(nbins - 1);
  std::int64_t prev = -1;
  for (std::size_t t = 0; t < n_xs; ++t) {
    const double v = xs[t];
    const double q = std::floor((v - origin) / width);
    const std::int64_t k = (q < 0.0) ? 0 : (q >= top ? nbins - 1 : static_cast<std::int64_t>(q));
    if (k == prev) {
      ++counts.back();
      continue;
    }
    push_empty_run(prev + 1, k - 1);
    push_bin(k, 1);
    prev = k;
  }
  push_empty_run(prev + 1, nbins - 1);
}

// ---------- NNS.gravity ----------

// R's default quantile (type 7) of sorted xs: position 1 + (n - 1) p.
static inline double quantile_type7(const double* xs, int n, double p) {
  const double h = (n - 1) * p;
  const int lo = (int)std::floor(h);
  const int hi = std::min(lo + 1, n - 1);
  return xs[lo] + (h - lo) * (xs[hi] - xs[lo]);
}

// Gravity of l finite values sorted ascending. Every caller reaches this one
// implementation, so a cell of a sorted partition and a plain vector give
// bit-identical results.
double gravity_sorted(const double* x, int l, bool discrete) {
  if (l == 0) return NA_REAL;
  if (l <= 3) {
    // median(x)
    double med = (l % 2 ? x[l/2] : 0.5*(x[l/2 - 1] + x[l/2]));
    if (discrete) return nearest_int_half_up(med);
    return med;
  }

  // Sorted, so the ends agree only when every value does.
  if (x[0] == x[l - 1]) return x[0];
  double range = std::fabs(x[l - 1] - x[0]);

  // The usual median and quartiles (#117): the floor-position order
  // statistics used before took the lower middle value for even n, so
  // gravity sat below the centre of symmetric data.
  const double q1 = quantile_type7(x, l, 0.25);
  const double q2 = quantile_type7(x, l, 0.50);
  const double q3 = quantile_type7(x, l, 0.75);

  double width = (q3 - q1) * std::pow((double)l, -0.5);
  if (!(width > 0.0) || !R_finite(width)) width = range / 128.0;

  std::vector<double> z_names;
  std::vector<int> counts;
  simple_bin_counts(x, (std::size_t)l, width, x[0], z_names, counts);
  const int lz = (int)counts.size();

  // If unique max, use neighborhood; else use all bins
  int maxc = 0;
  for (int c : counts) if (c > maxc) maxc = c;
  int ties = 0;
  for (int c : counts) if (c == maxc) ++ties;

  int lo = 0, hi = lz - 1;
  if (ties == 1) {
    int zc = 0; for (int i = 0; i < lz; ++i) if (counts[i] == maxc) { zc = i; break; }
    lo = std::max(0, zc - 1);
    hi = std::min(lz - 1, zc + 1);
  }

  // The mode term is the mean of the observations in those bins (#117): the
  // bins' left edges, used before, sat half a bin below the data. x is
  // sorted, so the observations of bins lo..hi are a contiguous slice.
  int a = 0;
  for (int i = 0; i < lo; ++i) a += counts[i];
  int e = a;
  for (int i = lo; i <= hi; ++i) e += counts[i];
  long double num = 0.0L;
  for (int t = a; t < e; ++t) num += (long double)x[t];
  double m = (e > a) ? (double)(num / (long double)(e - a)) : z_names[ (lo+hi)/2 ];

  double mu = mean_vec(x, (std::size_t)l);
  double mid = 0.25 * ( q2 + m + mu + 0.5*(q1 + q3) );

  double out = R_finite(mid) ? mid : q2;
  if (discrete) out = nearest_int_half_up(out);
  return out;
}

// Gravity of the finite values in x, which is sorted in place. The result
// depends only on the set of values, so input order is irrelevant.
double gravity_inplace(std::vector<double>& x, bool discrete) {
  const int l = (int)x.size();
  if (l == 0) return NA_REAL;
  if (l > 3) {
    // All equal: the first value as supplied (which keeps its sign of zero).
    bool all_eq = true;
    for (int i = 1; i < l; ++i) if (x[i] != x[0]) { all_eq = false; break; }
    if (all_eq) return x[0];
  }
  std::sort(x.begin(), x.end());
  return gravity_sorted(x.data(), l, discrete);
}

// Core gravity computation operating on a vector of finite values.
// Shared by NNS_gravity_cpp and the NNS.reg regression-point builder.
double gravity_value(std::vector<double> x, bool discrete) {
  return gravity_inplace(x, discrete);
}

// [[Rcpp::export]]
SEXP NNS_gravity_cpp(SEXP xSEXP, bool discrete) {
  NumericVector xR(xSEXP);
  std::vector<double> x;
  x.reserve(xR.size());
  for (double v : xR) if (R_finite(v)) x.push_back(v);

  return Rf_ScalarReal( gravity_value(x, discrete) );
}

// ---------- NNS.rescale ----------

// [[Rcpp::export]]
NumericVector NNS_rescale_cpp(SEXP xSEXP, double a, double b,
                              std::string method = "minmax",
                              Rcpp::Nullable<double> T_ = R_NilValue,
                              std::string type = "Terminal") {
  NumericVector xR(xSEXP);
  int n = xR.size();
  NumericVector out(n);
  
  std::transform(method.begin(), method.end(), method.begin(), ::tolower);
  std::transform(type.begin(), type.end(), type.begin(), ::tolower);
  
  if (method == "minmax") {
    double xmin = R_PosInf, xmax = R_NegInf;
    for (int i = 0; i < n; ++i) {
      if (R_finite(xR[i])) {
        if (xR[i] < xmin) xmin = xR[i];
        if (xR[i] > xmax) xmax = xR[i];
      }
    }
    if (!R_finite(xmin) || !R_finite(xmax) || xmax == xmin) {
      Rcpp::warning("All x identical: returning midpoint values");
      for (int i = 0; i < n; ++i)
        out[i] = ISNAN(xR[i]) ? xR[i] : (a + b) / 2.0;
      return out;
    }
    for (int i = 0; i < n; ++i) {
      out[i] = a + (b - a) * ( (xR[i] - xmin) / (xmax - xmin) );
    }
    return out;
  }
  
  if (method == "riskneutral") {
    const bool terminal = std::string("terminal").compare(0, type.size(), type) == 0;
    const bool discounted = std::string("discounted").compare(0, type.size(), type) == 0;
    if (terminal == discounted)
      stop("Invalid type: use 'Terminal' or 'Discounted'");
    if (T_.isNull()) stop("T (time to maturity) must be provided for riskneutral method");
    double T = Rcpp::as<double>(T_);
    if (!(a > 0.0)) stop("S_0 (a) must be positive for riskneutral method");
    double S0 = a;
    double r = b;
    
    // Compute scaling theta so that mean(out) matches target
    long double s = 0.0L; int cnt = 0;
    for (int i = 0; i < n; ++i) if (R_finite(xR[i])) { s += xR[i]; ++cnt; }
    double mx = (cnt > 0) ? (double)(s / cnt) : NA_REAL;
    
    if (!R_finite(mx) || mx <= 0.0)
      stop("Mean(x) must be positive/finite for riskneutral scaling");
    
    double target = discounted ? S0 : (S0 * std::exp(r * T));
    double theta = std::log(target / mx);
    
    for (int i = 0; i < n; ++i) out[i] = xR[i] * std::exp(theta);
    return out;
  }
  
  stop("Invalid method: use 'minmax' or 'riskneutral'");
  return out; // never reached
}


// ---------- NNS.mode ----------

// --- Triangular smoothing helper: 7-tap [1,2,3,4,3,2,1] with mirrored edges ---
static void smooth_counts_tri7(const std::vector<int>& counts, std::vector<double>& smooth) {
  static const int w[7] = {1,2,3,4,3,2,1};
  static const int Wsum = 16; // 1+2+3+4+3+2+1
  const int n = (int)counts.size();
  smooth.assign(n, 0.0);
  if (n == 0) return;
  
  // Mirror at edges (symmetric extension); the clamp only binds for n <= 3 bins.
  auto at = [&](int idx)->int{
    if (idx < 0)   idx = -idx;                     // reflect: -1 -> 1, -2 -> 2, ...
    if (idx >= n)  idx = 2*n - 2 - idx;            // reflect: n -> n-2, n+1 -> n-3, ...
    idx = std::min(std::max(idx, 0), n - 1);
    return counts[idx];
  };
  
  for (int i = 0; i < n; ++i) {
    int acc = 0;
    acc += w[0]*at(i-3); acc += w[1]*at(i-2); acc += w[2]*at(i-1);
    acc += w[3]*at(i  );
    acc += w[4]*at(i+1); acc += w[5]*at(i+2); acc += w[6]*at(i+3);
    smooth[i] = (double)acc / (double)Wsum;
  }
}

// [[Rcpp::export]]
SEXP NNS_mode_cpp(SEXP xSEXP, bool discrete, bool multi) {
  NumericVector xR(xSEXP);
  std::vector<double> x(xR.begin(), xR.end());
  
  // Coerce to numeric & drop non-finite
  std::vector<double> xnum; xnum.reserve(x.size());
  for (double v : x) if (R_finite(v)) xnum.push_back((double)v);
  
  const int l = (int)xnum.size();
  if (l == 0) return Rf_ScalarReal(NA_REAL);
  
  // ====================== DISCRETE PATH ======================
  if (discrete) {
    // Integerize and count exact frequencies. The key is a double so values
    // beyond the int range stay exact; "+ 0.0" folds -0.0 into the 0 key.
    std::unordered_map<double,int> freq; freq.reserve(l * 2u);
    for (double v : xnum) ++freq[ nearest_int_half_up(v) + 0.0 ];
    
    int maxf = 0; for (auto &kv : freq) if (kv.second > maxf) maxf = kv.second;
    
    std::vector<double> modes_int;
    for (auto &kv : freq) if (kv.second == maxf) modes_int.push_back(kv.first);
    std::sort(modes_int.begin(), modes_int.end());
    
    if (multi) {
      NumericVector out((int)modes_int.size());
      for (int i = 0; i < (int)modes_int.size(); ++i) out[i] = modes_int[i];
      return out;            // e.g., 2 3 4 for c(1,2,2,3,3,4,4,5)
    } else {
      // Tied modes: the one nearest the gravity of the data, then the lower
      // value, as in the continuous path; a mean of tied classes is no class.
      if (modes_int.size() == 1) return Rf_ScalarReal(modes_int[0]);
      const double g = gravity_value(xnum, false);
      double best_c = NA_REAL, best_d = R_PosInf;
      for (double m : modes_int) {
        const double dist = std::fabs(m - g);
        if (dist < best_d) { best_d = dist; best_c = m; }
      }
      return Rf_ScalarReal(best_c);
    }
  }
  
  // ====================== CONTINUOUS PATH ======================
  if (l <= 3) {
    std::vector<double> tmp = xnum; std::sort(tmp.begin(), tmp.end());
    double med = (l % 2 == 1) ? tmp[l/2] : 0.5*(tmp[l/2 - 1] + tmp[l/2]);
    return Rf_ScalarReal(med);
  }
  
  // All-equal?
  bool all_eq = true;
  for (int i = 1; i < l; ++i) if (xnum[i] != xnum[0]) { all_eq = false; break; }
  if (all_eq) return Rf_ScalarReal(xnum[0]);
  
  // Sort & basic stats
  std::sort(xnum.begin(), xnum.end());
  double range = std::fabs(xnum.back() - xnum.front());
  if (range == 0.0) return Rf_ScalarReal(xnum.front());
  
  // Quartiles & default bin width
  double q1, q2, q3;
  quartiles_like_R_code(xnum, q1, q2, q3);
  double width = (q3 - q1) * std::pow((double)l, -0.5);
  if (!(width > 0.0) || !R_finite(width)) width = range / 128.0;

  // ----- Discrete-valued data (#114) -----
  // When every gap between consecutive distinct values exceeds the bin width,
  // the histogram only spaces the distinct values out with empty bins, and
  // smoothing it moves the peaks off the values. The modes are then read from
  // the values' own frequencies: a run of consecutive distinct values with
  // equal counts is a mode when the runs beside it have lower counts (or it
  // reaches an end), so every mode is a data value and the end values count.
  {
    std::vector<double> vals;
    std::vector<int> cnt;
    for (int i = 0; i < l;) {
      int j = i + 1;
      while (j < l && xnum[j] == xnum[i]) ++j;
      vals.push_back(xnum[i]);
      cnt.push_back(j - i);
      i = j;
    }
    const int k = (int)vals.size();
    bool coarse = k >= 2;
    for (int i = 1; coarse && i < k; ++i) if (!(vals[i] - vals[i - 1] > width)) coarse = false;
    if (coarse) {
      std::vector<int> modes;
      for (int i = 0; i < k;) {
        int j = i + 1;
        while (j < k && cnt[j] == cnt[i]) ++j;
        const bool left_ok = (i == 0) || cnt[i - 1] < cnt[i];
        const bool right_ok = (j == k) || cnt[j] < cnt[i];
        if (left_ok && right_ok) for (int t = i; t < j; ++t) modes.push_back(t);
        i = j;
      }
      if (multi) {
        NumericVector out((int)modes.size());
        for (int t = 0; t < (int)modes.size(); ++t) out[t] = vals[modes[t]];
        return out;
      }
      // The most frequent mode; equally frequent ones go to the value nearest
      // the gravity of the data, then the lower value (modes ascend).
      int top = 0;
      for (int t : modes) top = std::max(top, cnt[t]);
      int n_top = 0, only = -1;
      for (int t : modes) if (cnt[t] == top) { ++n_top; only = t; }
      if (n_top == 1) return Rf_ScalarReal(vals[only]);
      const double g = gravity_value(xnum, false);
      double best_c = NA_REAL, best_d = R_PosInf;
      for (int t : modes) {
        if (cnt[t] != top) continue;
        const double dist = std::fabs(vals[t] - g);
        if (dist < best_d) { best_d = dist; best_c = vals[t]; }
      }
      return Rf_ScalarReal(best_c);
    }
  }

  // Histogram
  std::vector<double> z_names;   // left edge of each bin
  std::vector<int> counts;       // histogram counts
  simple_bin_counts(xnum.data(), xnum.size(), width, xnum.front(), z_names, counts);
  const int lz = (int)counts.size();
  if (lz == 0) return Rf_ScalarReal(NA_REAL);

  // xnum is sorted, so the observations of bins lo..hi are the contiguous
  // slice [start[lo], start[hi + 1]). A peak is centred on the mean of the
  // observations in its window rather than on the bin names, which sit up to
  // a bin below the data (#114); a window holding one value returns it.
  std::vector<int> start(lz + 1, 0);
  for (int b = 0; b < lz; ++b) start[b + 1] = start[b] + counts[b];
  auto obs_centre = [&](int lo, int hi) -> double {
    const int a = start[lo], e = start[hi + 1];
    if (e <= a) return z_names[lo];
    if (xnum[a] == xnum[e - 1]) return xnum[a];
    long double s = 0.0L;
    for (int t = a; t < e; ++t) s += (long double)xnum[t];
    return (double)(s / (long double)(e - a));
  };

  // For fallback paths
  int maxc = 0; for (int c : counts) if (c > maxc) maxc = c;

  // ----- Peak detection on smoothed counts -----
  std::vector<double> cs; smooth_counts_tri7(counts, cs);

  std::vector<int> peak_idx; peak_idx.reserve(lz);
  const double cs_max = *std::max_element(cs.begin(), cs.end());
  auto is_peak = [&](int i) {
    const double height = cs[i];
    if ((i > 0 && cs[i - 1] >= height) || (i + 1 < lz && cs[i + 1] >= height)) return false;
    if ((i < 3 || i > lz - 4) && height < cs_max) return false;
    const int lo = std::max(0, i - 3), hi = std::min(lz - 1, i + 3);
    return *std::max_element(cs.begin() + lo, cs.begin() + hi + 1) == height;
  };
  for (int i = 0; i < lz && lz >= 7; ++i) {
    if (!is_peak(i)) continue;
    // A tie inside the window counts only when another peak qualifies there too.
    bool tied = false, paired = false;
    for (int j = std::max(0, i - 3); j <= std::min(lz - 1, i + 3); ++j) {
      if (j == i || cs[j] != cs[i]) continue;
      tied = true;
      if (is_peak(j)) { paired = true; break; }
    }
    if (!tied || paired) peak_idx.push_back(i);
  }

  if (!peak_idx.empty()) {
    // Per-peak centre: the observations within +-3 bins
    NumericVector centers((int)peak_idx.size());
    for (int t = 0; t < (int)peak_idx.size(); ++t) {
      const int zc = peak_idx[t];
      centers[t] = obs_centre(std::max(0, zc - 3), std::min(lz - 1, zc + 3));
    }

    if (multi) {
      std::sort(centers.begin(), centers.end());
      const auto end = std::unique(centers.begin(), centers.end());
      return NumericVector(centers.begin(), end);
    } else {
      double best_h = cs[peak_idx[0]];
      for (int i : peak_idx) best_h = std::max(best_h, cs[i]);
      const double g = gravity_value(xnum, false);
      double best_c = NA_REAL, best_d = R_PosInf;
      for (int t = 0; t < (int)peak_idx.size(); ++t) {
        if (cs[peak_idx[t]] != best_h) continue;
        const double dist = std::fabs(centers[t] - g);
        if (dist < best_d || (dist == best_d && centers[t] < best_c)) { best_d = dist; best_c = centers[t]; }
      }
      return Rf_ScalarReal(best_c);
    }
  }

  // Fallback: if multiple global-max bins exist
  int ties = 0; for (int c : counts) if (c == maxc) ++ties;
  if (ties > 1) {
    if (multi) {
      NumericVector out(ties);
      int pos = 0;
      for (int i = 0; i < lz; ++i) if (counts[i] == maxc) out[pos++] = obs_centre(i, i);
      std::sort(out.begin(), out.end());
      return out;
    } else {
      // Tied highest bins: the one nearest the gravity of the data (then the
      // lower value), as for tied peaks above.
      const double g = gravity_value(xnum, false);
      double best_c = NA_REAL, best_d = R_PosInf;
      for (int i = 0; i < lz; ++i) {
        if (counts[i] != maxc) continue;
        const double c = obs_centre(i, i);
        const double dist = std::fabs(c - g);
        if (dist < best_d || (dist == best_d && c < best_c)) { best_d = dist; best_c = c; }
      }
      return Rf_ScalarReal(best_c);
    }
  }

  // Final fallback: single winning bin -> centre of the observations within +-1 bin
  int zc = 0; for (int i = 0; i < lz; ++i) if (counts[i] == maxc) { zc = i; break; }
  return Rf_ScalarReal(obs_centre(std::max(0, zc - 1), std::min(lz - 1, zc + 1)));
}
