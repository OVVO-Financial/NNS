x <- as.numeric(AirPassengers)
t <- seq_along(x)
res <- resid(lm(x ~ t))

meboot_reps <- function(...) {
  set.seed(1)
  NNS.meboot(x, reps = 50, rho = 1, ...)["replicates", ]$replicates
}
mean_slope <- function(R) mean(apply(R, 2, function(r) coef(lm(r ~ t))[2]))
mean_detrended_sd <- function(R) mean(apply(R, 2, function(r) sd(resid(lm(r ~ t)))))

test_that("a one-column data frame bootstraps like its column", {
  x <- data.frame(passengers = as.numeric(AirPassengers))
  set.seed(1)
  expected <- NNS.meboot(x$passengers, reps = 3, rho = 1)
  set.seed(1)
  expect_identical(NNS.meboot(x, reps = 3, rho = 1), expected)
})

test_that("drift = FALSE replicates are a flat baseline plus residual-scale noise", {
  R <- meboot_reps(drift = FALSE)
  expect_lt(abs(mean_slope(R)), 0.1)
  expect_lt(mean_detrended_sd(R), 1.1 * sd(res))
  expect_lt(mean(apply(R, 2, sd)), 1.1 * sd(res))
})

test_that("target_drift and target_drift_scale set the replicate slope", {
  expect_equal(mean_slope(meboot_reps(target_drift = 1)), 1, tolerance = 0.05)
  expect_equal(mean_slope(meboot_reps(target_drift_scale = 0.5)), 0.5 * coef(lm(x ~ t))[[2]], tolerance = 0.05)
  expect_lt(mean_detrended_sd(meboot_reps(target_drift = 1)), 1.1 * sd(res))
})

test_that("scl.adjustment scales the residual draw variance to the sample variance", {
  residuals <- c(1, 1, -4, 1, 1)
  x <- 2 * (1:5) + residuals
  draw <- function(...) {
    set.seed(1)
    NNS.meboot(x, reps = 4, target_drift = 0, digits = 14, expand.residual.sd = FALSE,
               expand.sd = FALSE, force.clt = FALSE, ...)
  }
  # Each tail has mass 1/5. The interior is uniform on [0,1] with mass 1/20 and has mass 11/20 at 1.
  fixed <- draw(scl.adjustment = TRUE, xmin = -6.5, xmax = 3.5)
  shifted <- draw(scl.adjustment = TRUE, xmin = -6.5, xmax = 3.5, reachbnd = FALSE)
  expect_equal((1 + fixed["kappa", ][[1]])^2 * 8399/1600, var(residuals))
  expect_equal((1 + shifted["kappa", ][[1]])^2 * 4399/1600, var(residuals))

  adjusted <- draw(scl.adjustment = TRUE)
  expect_equal(adjusted["replicates", ][[1]] - mean(x),
               (1 + adjusted["kappa", ][[1]]) * (draw()["replicates", ][[1]] - mean(x)))
})

test_that("force.clt spreads changed-drift replicate means on the residual scale", {
  set.seed(7)
  tt <- 1:100
  y <- 1000 + 10 * tt + rnorm(100)
  fit <- lm(y ~ tt)
  clt_reps <- function(...) {
    set.seed(1)
    NNS.meboot(y, reps = 10, rho = 1, ...)["replicates", ]$replicates
  }

  # The spread is that of a mean of n = 100 observations (#101).
  flat <- colMeans(clt_reps(drift = FALSE))
  expect_equal(mean(flat), mean(y), tolerance = 1e-6)
  expect_equal(sd(flat), sd(resid(fit)) / sqrt(100), tolerance = 1e-5)

  sloped <- colMeans(clt_reps(target_drift = 5))
  ref <- 5 * tt + resid(fit)
  expect_equal(mean(sloped), mean(y), tolerance = 1e-6)
  expect_equal(sd(sloped), sd(ref) / sqrt(100), tolerance = 1e-5)
})

test_that("level limits clip reconstructed paths drawn from the same residual tails", {
  x <- as.numeric(AirPassengers) - min(AirPassengers) + 1
  draw <- function(...) {
    set.seed(1)
    NNS.meboot(x, reps = 5, rho = 1, ...)
  }
  raw <- draw(expand.sd = FALSE, force.clt = FALSE)
  bounded <- draw(xmin = 0, xmax = 400)
  paths <- raw["replicates", ][[1]]
  expect_lt(min(paths), 0)
  expect_gt(max(paths), 400)
  expect_identical(bounded["replicates", ][[1]], pmin(pmax(paths, 0), 400))
  expect_identical(bounded[c("xmin", "xmax"), ], raw[c("xmin", "xmax"), ])
})

test_that("drift = FALSE keeps mean(x) as the replicate level", {
  for (clt in c(TRUE, FALSE)) {
    R <- meboot_reps(drift = FALSE, force.clt = clt)
    expect_equal(mean(R), mean(x), tolerance = 1e-3)
    expect_gt(min(R), 0)
  }
})

test_that("a target_drift equal to the original slope up to rounding keeps the default output", {
  ap <- as.numeric(AirPassengers); tt <- seq_along(ap)
  d_lm <- unname(coef(lm(ap ~ tt))[2])   # differs from fast_lm's slope by ~1e-15
  reps <- function(...) { set.seed(1); NNS.meboot(ap, reps = 20, rho = 1, ...)["replicates", ][[1]] }
  base <- reps()
  expect_equal(reps(target_drift = d_lm), base)
  expect_equal(reps(target_drift_scale = 1), base)
  # A real change of drift still takes the changed-drift path.
  expect_false(isTRUE(all.equal(reps(target_drift = 1.01 * d_lm), base)))
  # A target strictly inside the tolerance reproduces the default exactly,
  # which pins the snap to the original slope.
  d <- NNS:::fast_lm(tt, ap)$coef[2]
  tol <- sqrt(.Machine$double.eps) * max(abs(d), sd(ap) / length(ap))
  expect_identical(reps(target_drift = d + tol / 2), base)
})

test_that("the slope tolerance allows for rounding at a large series level", {
  t <- 1:20; set.seed(7); x <- 1e6 + .0001 * t + .01 * rnorm(20)
  d_lm <- unname(coef(lm(x ~ t))[2])   # same OLS fit, ~1e-11 from fast_lm's slope
  reps <- function(...) { set.seed(1); NNS.meboot(x, reps = 5, rho = .5, ...)["replicates", ][[1]] }
  expect_identical(reps(target_drift = d_lm), reps())
  # A real change of drift still takes the changed-drift path.
  expect_false(isTRUE(all.equal(reps(target_drift = .1), reps())))
})

test_that("force.clt spreads replicate means like means of n observations (#101)", {
  set.seed(1); x <- cumsum(rnorm(100))
  spread <- function(r) { set.seed(2); sd(colMeans(NNS.meboot(x, reps = r, rho = 1)["replicates", ]$replicates)) }
  s20 <- spread(20); s80 <- spread(80)
  # Before: 0.841 at 20 replicates and 0.420 at 80 (sd(x) / sqrt(reps)).
  expect_lt(abs(s80 / s20 - 1), 0.2)
  expect_equal(s80, sd(x) / sqrt(length(x)), tolerance = 0.2)
})

test_that("a bootstrap path retains its monthly calendar", {
  set.seed(1)
  paths <- NNS.meboot(AirPassengers, reps = 3, rho = 1)["replicates", ][[1]]
  expect_equal(frequency(paths[, 1]), 12)
  expect_equal(start(paths[, 1]), c(1949, 1))
  expect_length(window(paths[, 1], start = 1950, end = c(1950, 12)), 12)
})
