capture_frame <- function(fun, call) {
  captured <- new.env()
  suppressMessages(trace(
    fun, where = asNamespace("NNS"), print = FALSE,
    exit = bquote(assign("frame", environment(), envir = .(captured)))
  ))
  on.exit(suppressMessages(untrace(fun, where = asNamespace("NNS"))))
  force(call)
  captured$frame
}

boost_binary <- function(lo, hi) {
  y <- ifelse(iris$Species[1:140] == "setosa", hi, lo)
  NNS.boost(iris[1:140, 1:4], y, IVs.test = iris[c(1:3, 141:143), 1:4],
            epochs = 2, learner.trials = 3, feature.importance = FALSE,
            status = FALSE, seed = 1, pred.int = 0.9)
}

test_that("NNS.boost returns 0/1 response values for a 0/1 numeric response", {
  f <- boost_binary(0, 1)
  expect_equal(f$results, c(1, 1, 1, 0, 0, 0))
  expect_equal(unname(as.matrix(f$pred.int)), cbind(c(1, 1, 1, 0, 0, 0), c(1, 1, 1, 0, 0, 0)))
})

test_that("NNS.boost returns -5/5 response values for a -5/5 numeric response", {
  # Near-zero epoch scores can trigger the best-trial fallback by roundoff.
  # Accept only that documented warning, without requiring it on every platform.
  fallback_warning <- paste0(
    "No feature combination re-passed the objective cutoff during epochs; ",
    "using the best learner-trial combination. ",
    "Consider a lower [threshold] probability."
  )
  f <- withCallingHandlers(
    boost_binary(-5, 5),
    warning = function(w) {
      expect_identical(conditionMessage(w), fallback_warning)
      invokeRestart("muffleWarning")
    }
  )
  expect_equal(f$results, c(5, 5, 5, -5, -5, -5))
  expect_equal(unname(as.matrix(f$pred.int)), cbind(c(5, 5, 5, -5, -5, -5), c(5, 5, 5, -5, -5, -5)))
})

test_that("stack uses the response column's ordered levels", {
  x <- iris[1:100, 1:2]
  y <- ordered(iris$Species[1:100], levels = rev(levels(iris$Species)))
  fit <- function(y) NNS.stack(x, y, x[c(1, 100), ], method = 1, folds = 2,
    optimize.threshold = FALSE, status = FALSE, ncores = 1, seed = 17)
  control <- fit(y)
  expect_identical(fit(data.frame(y))$class.levels, control$class.levels)
  expect_equal(fit(data.frame(y))$probabilities, control$probabilities)
  unordered <- factor(y, levels = levels(y), ordered = FALSE)
  expect_identical(fit(unordered)$class.levels, control$class.levels)
})

test_that("Stack and Boost keep Date responses in days", {
  x <- rep(1:3, each = 8)
  day <- as.Date("2020-01-01") + x
  stack <- function(y) NNS.stack(x, y, 1:3, method = 1, folds = 2, order = "max",
                                 seed = 17, status = FALSE, ncores = 1)$stack
  boost <- function(y) NNS.boost(x, y, 1:3, type = "CLASS", epochs = 0, folds = 2,
                                 learner.trials = 1, seed = 17, status = FALSE,
                                 feature.importance = FALSE)$results
  expect_equal(stack(data.frame(day)), stack(as.numeric(day)), tolerance = 1e-12)
  expect_equal(boost(data.frame(day)), boost(as.numeric(day)), tolerance = 1e-12)
})

test_that("Stack and Boost distinguish both occurrences of a repeated hour", {
  x <- rep(1:3, each = 8)
  time <- as.POSIXct("2026-11-01 05:30:00", tz = "UTC") + (x - 1) * 3600
  attr(time, "tzone") <- "America/New_York"
  stack <- function(y) NNS.stack(x, y, 1:3, type = "CLASS", method = 1, folds = 2,
                                 seed = 17, status = FALSE, ncores = 1)
  boost <- function(y) NNS.boost(x, y, 1:3, type = "CLASS", epochs = 0, folds = 2,
                                 learner.trials = 1, seed = 17, status = FALSE,
                                 feature.importance = FALSE)
  expect_equal(stack(data.frame(time))$stack, stack(as.numeric(time))$stack, tolerance = 1e-12)
  actual <- boost(data.frame(time))
  control <- boost(as.numeric(time))
  expect_equal(actual$results, control$results, tolerance = 1e-12)
  expect_identical(actual$class.levels, control$class.levels)
})

test_that("logical predictors keep both levels for test and validation rows", {
  set.seed(12)
  x <- data.frame(flag = rep(TRUE, 20), num = rnorm(20))
  y <- factor(rep(c("a", "b"), 10))
  q <- data.frame(flag = c(FALSE, TRUE), num = c(0, 1))
  declared <- function(d) transform(d, flag = factor(flag, levels = c(FALSE, TRUE)))
  reg <- function(x, q, dummy) NNS.reg(x, y, point.est = q, factor.2.dummy = dummy,
                                       plot = FALSE)$Point.probabilities
  expect_equal(reg(x, q, TRUE), reg(declared(x), declared(q), TRUE), tolerance = 1e-12)
  expect_equal(reg(x, q, FALSE), reg(declared(x), declared(q), FALSE), tolerance = 1e-12)

  x$flag[17] <- FALSE
  stack <- function(x, q) NNS.stack(x, y, q, ts.test = 4, folds = 1, method = 1,
                                    seed = 1, status = FALSE, ncores = 1)$stack
  boost <- function(x, q) NNS.boost(x, y, q, ts.test = 4, folds = 1, learner.trials = 3,
                                    epochs = 0, seed = 1, status = FALSE,
                                    feature.importance = FALSE)$results
  expect_equal(stack(x, q), stack(declared(x), declared(q)), tolerance = 1e-12)
  expect_equal(boost(x, q), boost(declared(x), declared(q)), tolerance = 1e-12)
})

test_that("NNS.stack codes a character response like the equivalent factor", {
  idx <- c(101:140, 1:100)
  x <- iris[idx, 1:4]
  y <- as.character(iris$Species[idx])
  run <- function(dv) NNS.stack(x, dv, IVs.test = iris[141:150, 1:4], method = 1,
                                folds = 2, status = FALSE, ncores = 1, seed = 1)
  chr <- run(y)
  expect_identical(chr$class.levels, c("setosa", "versicolor", "virginica"))
  expect_identical(chr, run(factor(y)))
})

test_that("NNS.stack encodes a character predictor like the equivalent factor", {
  set.seed(4)
  x <- data.frame(x = rnorm(60), g = rep(c("zeta", "alpha", "mid"), 20))
  y <- x$x + rep(c(2, 3, 0), 20) + rnorm(60)
  xf <- x
  xf$g <- factor(xf$g)
  run <- function(iv) NNS.stack(iv, y, IVs.test = iv[1:5, ], method = 2, folds = 2,
                                status = FALSE, ncores = 1, seed = 1)
  chr <- run(x)
  expect_identical(names(chr$NNS.dim.red.coefficients), c("x", "g__alpha", "g__mid", "g__zeta"))
  expect_identical(chr, run(xf))
})

balance_y <- c(1, 1, 1, 2, 2, 2, 3)

test_that("NNS.stack balancing keeps a single-member class", {
  set.seed(9)
  x <- data.frame(a = rnorm(60), b = rnorm(60))
  frame <- capture_frame("NNS.stack", NNS::NNS.stack(
    x, factor(rep(1:3, c(29, 29, 2))), IVs.test = x[1:3, ], method = 1,
    balance = TRUE, folds = 2, seed = 1, ncores = 1, status = FALSE
  ))
  set.seed(1)
  idx <- frame$.balance_indices(balance_y)
  expect_identical(as.integer(table(balance_y[idx])), c(4L, 4L, 4L))
})

test_that("NNS.boost balancing keeps a single-member class", {
  set.seed(9)
  x <- data.frame(a = rnorm(60), b = rnorm(60))
  frame <- capture_frame("NNS.boost", NNS::NNS.boost(
    x, factor(rep(1:3, c(29, 29, 2))), IVs.test = x[1:3, ], type = "CLASS",
    balance = TRUE, epochs = 0, learner.trials = 3, feature.importance = FALSE,
    status = FALSE, seed = 1
  ))
  set.seed(1)
  z <- frame$.balance_training(data.frame(i = seq_along(balance_y)), balance_y)
  expect_identical(as.integer(table(z$y)), c(4L, 4L, 4L))
  expect_identical(balance_y[z$x$i], z$y)
})

test_that("NNS.stack scores the multivariate ALL candidate with NNS.reg(n.best = 'all')", {
  set.seed(5)
  x <- data.frame(a = rnorm(160), b = rnorm(160))
  y <- rnorm(160)
  frame <- capture_frame("NNS.stack", NNS::NNS.stack(
    x, y, IVs.test = x[1:3, ], method = 1, seed = 1, ncores = 1, status = FALSE
  ))
  oof <- rep(NA_real_, length(y))
  for (s in frame$splits) {
    design <- frame$.method1_design_for_split(s$train, s$validation)
    fit <- NNS.reg(design$train, frame$y_fit_all[s$train], point.est = design$test,
                   n.best = "all", order = frame$order, dist = frame$dist, type = "REG",
                   factor.2.dummy = FALSE, plot = FALSE, residual.plot = FALSE,
                   ncores = 1, point.only = TRUE)
    oof[s$validation] <- fit$Point.est
  }
  expect_equal(frame$candidate_raws$all, oof, tolerance = 1e-12)
  expect_equal(unname(frame$candidate_scores["all"]), sum((oof - y)^2), tolerance = 1e-12)
})

test_that("NNS.stack scores the univariate ALL candidate with the deployed NNS.reg fit", {
  set.seed(5)
  x <- data.frame(a = rnorm(160))
  y <- rnorm(160)
  frame <- capture_frame("NNS.stack", NNS::NNS.stack(
    x, y, IVs.test = x[1:3, , drop = FALSE], method = 1, seed = 1, ncores = 1, status = FALSE
  ))
  oof <- rep(NA_real_, length(y))
  for (s in frame$splits) {
    design <- frame$.method1_design_for_split(s$train, s$validation)
    fit <- NNS.reg(design$train[[1L]], frame$y_fit_all[s$train], point.est = design$test[[1L]],
                   n.best = "all", order = frame$order, dist = frame$dist, type = "REG",
                   factor.2.dummy = FALSE, plot = FALSE, residual.plot = FALSE,
                   ncores = 1, point.only = TRUE)
    oof[s$validation] <- fit$Point.est
  }
  expect_equal(frame$candidate_raws$all, oof, tolerance = 1e-12)
  expect_equal(unname(frame$candidate_scores["all"]), sum((oof - y)^2), tolerance = 1e-12)
})

test_that("Stack fits character levels on the chronological training prefix", {
  x <- data.frame(g = c(rep(c("a", "b"), 16), rep("new", 8)), z = 1:40)
  expect_error(NNS.stack(x, x$z, method = 2, ts.test = 8, folds = 2,
                         ncores = 1, status = FALSE), "unseen level.*new")
  x$g <- factor(x$g)
  fit <- NNS.stack(x, x$z, method = 2, ts.test = 8, folds = 2,
                   ncores = 1, status = FALSE)
  expect_true(is.finite(fit$OBJfn.dim.red))
})

test_that("balancing keeps character levels observed in the training fold", {
  x <- data.frame(g = rep("a", 40))
  x$g[c(1, 35)] <- "rare"
  y <- factor(rep(c("A", "A", "A", "B"), 10))
  fit <- NNS.stack(x, y, x[35, , drop = FALSE], method = 1, ts.test = 8,
                   folds = 1, balance = TRUE, seed = 3, ncores = 1, status = FALSE)
  expect_equal(fit$stack, 1)
})

test_that("Boost accepts declared levels absent from training", {
  x <- data.frame(g = factor(rep(c("a", "b"), 20), levels = c("c", "b", "a")))
  fit <- NNS.boost(x, rep(c(10, 20), 20), data.frame(g = c("a", "c", "b")),
                   epochs = 0, learner.trials = 1, feature.importance = FALSE,
                   type = "CLASS", folds = 2, seed = 9, status = FALSE)
  expect_equal(fit$results, c(10, 10, 20))
})

test_that("boost's objective sees response values for a two-valued numeric response", {
  set.seed(1)
  x <- matrix(rnorm(240), 80, 3)
  y <- ifelse(x[, 1] + rnorm(80, sd = .5) > 0, 5, -5)
  seen <- numeric(0)
  record <- function(a) seen <<- c(seen, a)
  loss <- as.expression(bquote({
    .(record)(actual)
    sum((predicted - actual)^2)
  }))
  NNS.boost(x, y, x[1:10, ], obj.fn = loss, learner.trials = 3, epochs = 0,
            threshold = 1, CV.size = .25, seed = 1, status = FALSE,
            feature.importance = FALSE)
  expect_setequal(unique(seen), c(-5, 5))
  seen <- numeric(0)
  NNS.boost(x, ifelse(y > 0, .2, -.1), x[1:10, ], obj.fn = loss, learner.trials = 3,
            epochs = 0, threshold = 1, CV.size = .25, seed = 1, status = FALSE,
            feature.importance = FALSE)
  expect_true(all(seen %in% c(-.1, .2)))
})